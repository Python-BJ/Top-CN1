<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文总榜 > 资料类 > Dart
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|
|:-|:-|:-|:-|:-|
|1|[AweiLoveAndroid/Flutter-learning](https://github.com/AweiLoveAndroid/Flutter-learning)|:octocat::fire: :+1:  :star2:  :star: :star::star: Flutter all you want.Flutter install,flutter samples,Flutter projects,Flutter plugin,Flutter problems,Dart codes,etc.Flutter安装和配置，Flutter开发遇到的难题，Flut ...|5084|2022-02-12|
|2|[huanxsd/flutter_shuqi](https://github.com/huanxsd/flutter_shuqi)|高仿书旗小说 Flutter版，支持iOS、Android|2407|2022-05-23|
|3|[Sky24n/flustars](https://github.com/Sky24n/flustars)|🔥🔥🔥  Flutter common utils library. SpUtil, ScreenUtil,WidgetUtil.  也许是目前最好用的SharedPreferences工具类。WidgetUtil 获取图片尺寸宽高, View尺寸&在屏幕上的坐标。|1736|2022-06-01|
|4|[yechaoa/wanandroid_flutter](https://github.com/yechaoa/wanandroid_flutter)|:collision::collision::collision:【Flutter版】玩安卓，非常适合学习，代码不多、注释多。|620|2022-03-29|
|5|[RxReader/wechat_kit](https://github.com/RxReader/wechat_kit)|flutter版微信登录/分享/支付 SDK|554|2022-07-29|
|6|[lrorpilla/jidoujisho](https://github.com/lrorpilla/jidoujisho)|A highly versatile and modular framework enabling language-agnostic immersion learning on mobile.|301|2022-05-24|
|7|[nightmare-space/speed_share](https://github.com/nightmare-space/speed_share)|Speed Share is a highly available file sharing terminal on LAN(local area network) developed by flutter framework.|236|2022-07-26|
|8|[longer96/flutter_pickers](https://github.com/longer96/flutter_pickers)|flutter 选择器库，包括日期及时间选择器（可设置范围）、单项选择器（可用于性别、民族、学历、星座、年龄、身高、体重、温度等）、城市地址选择器（分省级、地级及县级）、多项选择器等…… 欢迎Fork & pr贡献您的代码，大家共同学习|211|2022-06-05|
|9|[RxReader/tencent_kit](https://github.com/RxReader/tencent_kit)|flutter版QQ登录/分享|188|2022-07-29|
|10|[pheromone/Flutter_learn_demo](https://github.com/pheromone/Flutter_learn_demo)|Flutter_learn_demo  Flutter学习历程|114|2022-08-01|
|11|[RxReader/weibo_kit](https://github.com/RxReader/weibo_kit)|flutter版新浪微博登录/分享|92|2022-07-29|
|12|[NewPracticer/Python-Flutter-Dart-DataStructure](https://github.com/NewPracticer/Python-Flutter-Dart-DataStructure)|使用python、flutter的dart语言重写数据结构与算法。包括线性搜索、选择排序、插入排序、栈，队列，链表、递归、归并排序、快速排序、二分搜索、二分搜索树、集合 和 映射、堆、优先队列、冒泡排序、希尔排序、线段树、Trie字典树、并查集、AVL树、红黑树、哈希表、计数排序、LSD基数排序、MSD排序，桶排序、字符串匹配、图的邻接矩阵、邻接表，深度优先遍历及应用|73|2022-03-30|
|13|[idootop/watermelon](https://github.com/idootop/watermelon)|Watermelon is a game developed using Flutter+Flame+Forge2D. For learning purposes only. 一个开源的 Flame 小游戏（Flutter版合成大西瓜）|73|2022-04-04|
|14|[asjqkkkk/flutter-blog](https://github.com/asjqkkkk/flutter-blog)|💻使用flutter完成的个人web博客.|49|2022-02-04|
|15|[Daniel-Ioannou/flutter_country_picker](https://github.com/Daniel-Ioannou/flutter_country_picker)|A flutter package to select a country from a list of countries.|46|2022-05-14|
|16|[xiaojia21190/ZY_Player_flutter](https://github.com/xiaojia21190/ZY_Player_flutter)|影视 漫画 小说 听书 |25|2022-08-02|
|17|[HuRuWo/HowToReserveFlutter](https://github.com/HuRuWo/HowToReserveFlutter)|HowToReserveFlutter is some  reverse flutter note 。flutter逆向笔记，如何一步一步分析 flutter apk。|22|2022-04-02|
|18|[kangshaojun/study-notes](https://github.com/kangshaojun/study-notes)|Flutter React Golang WebRTC等技术学习笔记|12|2022-05-01|
|19|[jianguo888/Flutter-Web-template](https://github.com/jianguo888/Flutter-Web-template)|Flutter Web - 仪表板网站模板教你如何构建响应式仪表板网站。|9|2022-02-09|
|20|[idootop/fallDown](https://github.com/idootop/fallDown)|FallDown is a game developed using Flutter+Flame+Box2D. For learning purposes only.  一个开源的 Flame 小游戏。|9|2022-04-04|
|21|[JerryAlexLiang/flutter_wan_android_getx](https://github.com/JerryAlexLiang/flutter_wan_android_getx)|WanAndroid Flutter版 基于GetX ，欢迎互相交流学习， Gitee：https://gitee.com/JerryAlexLiang/flutter_wan_android_getx.git|7|2022-02-23|
|22|[idootop/scroll_master](https://github.com/idootop/scroll_master)|An example showing how to handle common scrolling gesture conflicts in Flutter. 一个展示如何处理Flutter中的常见滑动手势冲突的示例。|7|2022-03-27|
|23|[idootop/Design-Patterns-Dart](https://github.com/idootop/Design-Patterns-Dart)|23 Design Patterns in dart and 6 Design Principles. Dart中的23种设计模式和6大设计原则|7|2022-03-27|
|24|[ifredom/flutter_plugins_example](https://github.com/ifredom/flutter_plugins_example)|flutter第三方插件：地图，图表，蓝牙，等使用示例集合|7|2022-06-03|
|25|[feiyvflutter/Flutter](https://github.com/feiyvflutter/Flutter)|搜集工作和学习中用到的Flutter相关的技术，包含代码，遇到报错信息，以及解决办法。|7|2022-07-28|
|26|[Petterpx/FlutterQuickExample](https://github.com/Petterpx/FlutterQuickExample)|Flutter入门示例，对照着Flutter实战书籍写的一个demo。|3|2022-06-27|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
