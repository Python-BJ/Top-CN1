<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > C
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[LookCos/learn-data-structures](https://github.com/LookCos/learn-data-structures)|数据结构（C语言描述）学习笔记|193|2022-03-12|2021-10-09|
|2|[realYurkOfGitHub/translation-Introduction-to-HPC](https://github.com/realYurkOfGitHub/translation-Introduction-to-HPC)|为 Eijhout 教授的Introduction to HPC提供中文翻译、 PPT和Lab。|82|2022-04-11|2021-10-18|
|3|[feiskyer/ebpf-apps](https://github.com/feiskyer/ebpf-apps)|极客时间专栏《eBPF 核心技术与实战》案例|79|2022-04-05|2021-11-01|
|4|[pandengyang/peach](https://github.com/pandengyang/peach)|桃花源（英文名为 peach）是一个迷你虚拟机，用于学习 Intel 硬件虚拟化技术。|70|2022-03-19|2022-03-19|
|5|[akerdi/buildyourownsqlite](https://github.com/akerdi/buildyourownsqlite)|制作一个自己的sqlite教程|11|2022-06-22|2022-04-23|
|6|[Googol2002/NJU-ICS2021-PA](https://github.com/Googol2002/NJU-ICS2021-PA)|2021年秋季学期 南京大学ICS课程 PA实验部分|11|2022-02-24|2021-09-09|
|7|[Egahp/bl706_dk](https://github.com/Egahp/bl706_dk)|BL706 Develop Kit 开发板资料|8|2022-04-02|2022-01-28|
|8|[ZCXu1/HUST-CSE-Experiments](https://github.com/ZCXu1/HUST-CSE-Experiments)|华中科技大学网络空间安全学院课程设计及课程实验合集|6|2022-07-01|2022-06-18|
|9|[Matrix53/parallel-programming](https://github.com/Matrix53/parallel-programming)|北航《并行程序设计》课程lab合集|6|2022-05-14|2022-04-26|
|10|[chintsan-code/cuda_by_example](https://github.com/chintsan-code/cuda_by_example)|GPU高性能编程CUDA实战随书代码|5|2022-05-24|2022-04-15|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
