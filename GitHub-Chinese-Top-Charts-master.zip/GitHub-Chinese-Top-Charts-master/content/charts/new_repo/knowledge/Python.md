<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Python
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[MenghaoGuo/Awesome-Vision-Attentions](https://github.com/MenghaoGuo/Awesome-Vision-Attentions)|Summary of related papers on visual attention. Related code will be released based on Jittor gradually.    |1780|2022-06-09|2021-09-01|
|2|[Threekiii/Awesome-Redteam](https://github.com/Threekiii/Awesome-Redteam)|一个红队知识仓库|1187|2022-07-20|2022-02-08|
|3|[4ra1n/JavaSecInterview](https://github.com/4ra1n/JavaSecInterview)|Java安全研究与安全开发面试题库，同是也是常见知识点的梳理和总结，包含问题和详细的答案，计划定期更新|1019|2022-05-26|2022-02-14|
|4|[saveweb/review-2021](https://github.com/saveweb/review-2021)|今年，你写年终总结了吗？|697|2022-07-27|2021-12-31|
|5|[SkywalkerJi/mdt](https://github.com/SkywalkerJi/mdt)|Yu-Gi-Oh! Master Duel Translation Script|654|2022-07-11|2022-01-24|
|6|[wdmpa/content-farm-list](https://github.com/wdmpa/content-farm-list)|List of content farm sites like g.penzai.com.|486|2022-04-15|2021-10-09|
|7|[open-mmlab/mmfewshot](https://github.com/open-mmlab/mmfewshot)|OpenMMLab FewShot Learning Toolbox and Benchmark|447|2022-06-22|2021-11-22|
|8|[shengxinjing/it-roadmap](https://github.com/shengxinjing/it-roadmap)|大圣的前端学习路线图|436|2022-07-13|2021-11-27|
|9|[ls1248659692/leetcode](https://github.com/ls1248659692/leetcode)|python  数据结构与算法   leetcode 算法题与书籍 刷算法全靠套路与总结！Crack LeetCode, not only how, but also why.|400|2022-05-02|2022-02-13|
|10|[gm365/Web3_Tutorial](https://github.com/gm365/Web3_Tutorial)|🐳 Web3科学家极简入门指南|281|2022-05-25|2022-05-20|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
