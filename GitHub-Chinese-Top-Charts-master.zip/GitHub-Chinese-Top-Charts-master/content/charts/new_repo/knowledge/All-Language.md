<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > All Language
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Language|Updated|Created|
|:-|:-|:-|:-|:-|:-|:-|
|1|[WeNeedHome/SummaryOfLoanSuspension](https://github.com/WeNeedHome/SummaryOfLoanSuspension)|全国各省市停贷通知汇总|19804|HTML|2022-08-02|2022-07-12|
|2|[geekan/HowToLiveLonger](https://github.com/geekan/HowToLiveLonger)|程序员延寿指南   A programmer's guide to live longer|19043|-|2022-06-17|2022-04-16|
|3|[PKUFlyingPig/cs-self-learning](https://github.com/PKUFlyingPig/cs-self-learning)|计算机自学指南|10886|HTML|2022-07-26|2021-10-20|
|4|[mli/paper-reading](https://github.com/mli/paper-reading)|深度学习经典、新论文逐段精读|10684|-|2022-07-29|2021-10-22|
|5|[wmjordan/PDFPatcher](https://github.com/wmjordan/PDFPatcher)|PDF补丁丁——PDF工具箱，可以编辑书签、剪裁旋转页面、解除限制、提取或合并文档，探查文档结构，提取图片、转成图片等等|6070|C#|2022-07-22|2021-12-24|
|6|[liyupi/mianshiya-public](https://github.com/liyupi/mianshiya-public)|干净免费的面试刷题网站，帮助大家拿到满意的 offer！💎 React 前端 + Node 后端 + 云开发全栈项目 by 程序员鱼皮|3128|TypeScript|2022-04-29|2022-01-04|
|7|[Dujltqzv/Some-Many-Books](https://github.com/Dujltqzv/Some-Many-Books)|个人收藏书籍列表　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　 ...|2783|-|2022-05-30|2021-09-05|
|8|[qiangmzsx/Software-Engineering-at-Google](https://github.com/qiangmzsx/Software-Engineering-at-Google)|《Software Engineering at Google》的中文翻译版本|2544|HTML|2022-07-28|2021-11-28|
|9|[hectorqin/reader](https://github.com/hectorqin/reader)|阅读3服务器版，桌面端，iOS可用。后端 Kotlin + Spring Boot + Vert.x + Coroutine ；前端 Vue.js + Element。麻烦点点star，关注一下公众号【假装大佬】❗️|2541|Kotlin|2022-08-02|2021-08-13|
|10|[kuaifan/dootask](https://github.com/kuaifan/dootask)|DooTask是一款轻量级的开源在线项目任务管理工具，提供各类文档协作工具、在线思维导图、在线流程图、项目管理、任务分发、即时IM，文件管理等工具。|2343|PHP|2022-07-28|2021-08-29|
|11|[foxsen/archbase](https://github.com/foxsen/archbase)|教科书《计算机体系结构基础》（胡伟武等，第三版）的开源版本|2220|TeX|2022-04-18|2021-10-27|
|12|[aykutkardas/regexlearn.com](https://github.com/aykutkardas/regexlearn.com)|Learn RegEx step by step, from zero to advanced.|1959|TypeScript|2022-08-01|2021-08-28|
|13|[HZFE/awesome-interview](https://github.com/HZFE/awesome-interview)|剑指前端 Offer|1928|HTML|2022-07-04|2021-08-23|
|14|[parallel101/course](https://github.com/parallel101/course)|高性能并行编程与优化 - 课件|1813|C++|2022-07-31|2021-12-10|
|15|[wangdoc/clang-tutorial](https://github.com/wangdoc/clang-tutorial)|C 语言教程|1790|-|2022-07-28|2021-09-04|
|16|[MenghaoGuo/Awesome-Vision-Attentions](https://github.com/MenghaoGuo/Awesome-Vision-Attentions)|Summary of related papers on visual attention. Related code will be released based on Jittor gradually.    |1780|Python|2022-06-09|2021-09-01|
|17|[TechXueXi/techxuexi-js](https://github.com/TechXueXi/techxuexi-js)|油猴等插件的 学习强国 js 代码 45分/天|1773|JavaScript|2022-03-29|2021-10-11|
|18|[RanKKI/LawRefBook](https://github.com/RanKKI/LawRefBook)|中华人民共和国法律手册|1616|Swift|2022-07-13|2022-02-25|
|19|[openmlsys/openmlsys-zh](https://github.com/openmlsys/openmlsys-zh)|《Machine Learning Systems: Design and Implementation》- Chinese Version|1573|TeX|2022-07-31|2022-01-18|
|20|[dundunnp/auto_xuexiqiangguo](https://github.com/dundunnp/auto_xuexiqiangguo)|每日拿满61分！免root，四人赛双人对战秒答，安卓端学习强国自动化脚本|1452|JavaScript|2022-08-01|2021-11-24|
|21|[BetaSu/fe-hunter](https://github.com/BetaSu/fe-hunter)|每天一道题，3个月后，你就是面试小能手，答题还能赚钱哦|1375|JavaScript|2022-04-22|2022-03-21|
|22|[Baiyuetribe/paper2gui](https://github.com/Baiyuetribe/paper2gui)|Convert AI papers to GUI，Make it easy and convenient for everyone to use artificial intelligence technology。让每个人都简单方便的使用前沿人工智能技术|1275|Jupyter Notebook|2022-07-04|2021-10-10|
|23|[Threekiii/Awesome-Redteam](https://github.com/Threekiii/Awesome-Redteam)|一个红队知识仓库|1187|Python|2022-07-20|2022-02-08|
|24|[wa-lang/ugo-compiler-book](https://github.com/wa-lang/ugo-compiler-book)|:books: µGo语言实现(从头开发一个迷你Go语言编译器)[Go版本+Rust版本]|1137|Go|2022-08-02|2021-11-03|
|25|[4ra1n/JavaSecInterview](https://github.com/4ra1n/JavaSecInterview)|Java安全研究与安全开发面试题库，同是也是常见知识点的梳理和总结，包含问题和详细的答案，计划定期更新|1019|Python|2022-05-26|2022-02-14|
|26|[krahets/LeetCode-Book](https://github.com/krahets/LeetCode-Book)|《剑指 Offer》 Python, Java, C++ 解题代码，LeetBook《图解算法数据结构》配套代码仓。|905|Java|2022-02-21|2021-12-17|
|27|[skyzh/type-exercise-in-rust](https://github.com/skyzh/type-exercise-in-rust)|Learn Rust black magics by implementing an expression framework in database systems|873|Rust|2022-04-12|2022-01-20|
|28|[Cats-Team/AdRules](https://github.com/Cats-Team/AdRules)|List of ad filters based on Chinese locale. 基于中文区的广告规则|783|Shell|2022-08-02|2021-08-06|
|29|[yuesong-feng/30dayMakeCppServer](https://github.com/yuesong-feng/30dayMakeCppServer)|30天自制C++服务器，包含教程和源代码|778|C++|2022-07-14|2021-11-30|
|30|[chowa/ejyy](https://github.com/chowa/ejyy)|「e家宜业」是一整套开源智慧物业解决方案，基于nodejs、typescript、koa、vue开发，包含web中台、业主小程序、员工小程序、公众号、物联网应用等，涵盖业主服务、物业运营、智能物联、数据统计等主要业务。|772|TypeScript|2022-07-31|2021-11-08|
|31|[zkqiang/hangzhou-house-guide](https://github.com/zkqiang/hangzhou-house-guide)|2022年杭州购房指南，根据个人多年购房选房经历，总结而成的一篇买房攻略，涉及新房摇号和二手房选购，包含大量杭州城市规划资料。|760|JavaScript|2022-05-26|2022-03-01|
|32|[flutterchina/flutter_in_action_2nd](https://github.com/flutterchina/flutter_in_action_2nd)|《Flutter实战 第二版》- 书稿（未完成）|756|HTML|2022-05-10|2021-08-29|
|33|[vuejs-translations/docs-zh-cn](https://github.com/vuejs-translations/docs-zh-cn)|Vue 文档官方中文翻译 ｜ Official Chinese translation for Vue docs|729|Vue|2022-08-02|2022-01-05|
|34|[personqianduixue/Math_Model](https://github.com/personqianduixue/Math_Model)|数学建模、美赛、美国大学生数学建模竞赛、全国大学生数学建模竞赛、华为杯研究生数学建模、国赛LaTeX模板、美赛LaTeX模板、mathorcup、电工杯、华中赛、APMCM、深圳杯、中青杯、华东杯、数维杯、东三省数学建模、认证杯、数学建模书籍、常用matlab算法、国赛评阅要点、软件模型算法汇总、智能算法、优化算法|719|MATLAB|2022-03-25|2021-10-09|
|35|[saveweb/review-2021](https://github.com/saveweb/review-2021)|今年，你写年终总结了吗？|697|Python|2022-07-27|2021-12-31|
|36|[eryajf/HowToStartOpenSource](https://github.com/eryajf/HowToStartOpenSource)|⚗️ GitHub开源项目维护协作指南|675|JavaScript|2022-08-02|2022-07-02|
|37|[SkywalkerJi/mdt](https://github.com/SkywalkerJi/mdt)|Yu-Gi-Oh! Master Duel Translation Script|654|Python|2022-07-11|2022-01-24|
|38|[tyrchen/geektime-rust](https://github.com/tyrchen/geektime-rust)|我的极客时间 Rust 课程的代码仓库，随课程更新|616|Rust|2022-04-28|2021-08-17|
|39|[midisec/BypassAnti-Virus](https://github.com/midisec/BypassAnti-Virus)|免杀姿势学习、记录、复现。|601|C++|2022-07-10|2022-02-18|
|40|[haixiangyan/jest-tutorial](https://github.com/haixiangyan/jest-tutorial)|🃏《Jest 实践指南》|566|Shell|2022-07-08|2022-04-24|
|41|[Le0nsec/SecCrawler](https://github.com/Le0nsec/SecCrawler)|一个方便安全研究人员获取每日安全日报的爬虫和推送程序，目前爬取范围包括先知社区、安全客、Seebug Paper、跳跳糖、奇安信攻防社区、棱角社区以及绿盟、腾讯玄武、天融信、360等实验室博客，持续更新中。|555|Go|2022-05-06|2021-12-14|
|42|[ttglad/learning](https://github.com/ttglad/learning)|学习强国浏览器插件，自动阅读、观看视频、每日答题、每周答题、专项答题，每日45分！|497|JavaScript|2022-06-24|2021-09-09|
|43|[wdmpa/content-farm-list](https://github.com/wdmpa/content-farm-list)|List of content farm sites like g.penzai.com.|486|Python|2022-04-15|2021-10-09|
|44|[ethminerpro/minerproxy](https://github.com/ethminerpro/minerproxy)|本程序为正版原创，开发费恒定！无论你抽3%还是30%，甚至80%，都是0.3%开发费！无视CC攻击，不怕扫描攻击，内置加密证书，抽水设置范围支持0.1%-80%；无需繁琐设置，支持ETC！支持自定义证书，欢迎实测！|464|Go|2022-05-14|2022-03-02|
|45|[Metarget/cloud-native-security-book](https://github.com/Metarget/cloud-native-security-book)|《云原生安全：攻防实践与体系构建》资料仓库|460|Go|2022-06-01|2021-09-25|
|46|[rootsongjc/kubernetes-hardening-guidance](https://github.com/rootsongjc/kubernetes-hardening-guidance)|《Kubernetes 加固手册》（美国国家安全局出品）- https://jimmysong.io/kubernetes-hardening-guidance|460|Shell|2022-03-13|2021-08-08|
|47|[open-mmlab/mmfewshot](https://github.com/open-mmlab/mmfewshot)|OpenMMLab FewShot Learning Toolbox and Benchmark|447|Python|2022-06-22|2021-11-22|
|48|[LeeJim/HowToCookOnMiniprogram](https://github.com/LeeJim/HowToCookOnMiniprogram)|程序员做菜指南 for Miniprogram，将程序员精神贯彻到底|444|JavaScript|2022-05-06|2022-03-01|
|49|[shengxinjing/it-roadmap](https://github.com/shengxinjing/it-roadmap)|大圣的前端学习路线图|436|Python|2022-07-13|2021-11-27|
|50|[xushengfeng/eSearch](https://github.com/xushengfeng/eSearch)|截屏OCR搜索翻译以图搜图贴图录屏 Screenshot  OCR  search  translate  search for picture  paste the picture on the screen  screen recorder|436|JavaScript|2022-07-29|2021-10-06|
|51|[course-dasheng/fe-algorithm](https://github.com/course-dasheng/fe-algorithm)|前端啃算法，一次性解决前端工程师的算法学习问题|407|JavaScript|2022-07-06|2022-02-22|
|52|[ls1248659692/leetcode](https://github.com/ls1248659692/leetcode)|python  数据结构与算法   leetcode 算法题与书籍 刷算法全靠套路与总结！Crack LeetCode, not only how, but also why.|400|Python|2022-05-02|2022-02-13|
|53|[bestxtools/awesome-toolbox-chinese](https://github.com/bestxtools/awesome-toolbox-chinese)|🧰 优秀工具箱集合 - 收集，推荐好用、优秀的工具箱。工具箱大全。|387|Shell|2022-07-27|2022-03-04|
|54|[lemoex/oci-help](https://github.com/lemoex/oci-help)|甲骨文实例抢购教程|378|Go|2022-05-29|2021-10-18|
|55|[virginiakm1988/ML2022-Spring](https://github.com/virginiakm1988/ML2022-Spring)|**Official** 李宏毅 (Hung-yi Lee) 機器學習 Machine Learning 2022 Spring|376|Jupyter Notebook|2022-05-05|2022-02-20|
|56|[qinhua/halo-theme-joe2.0](https://github.com/qinhua/halo-theme-joe2.0)|🌈 一款 Halo 博客主题 Joe2.0|367|JavaScript|2022-06-03|2021-09-16|
|57|[phodal/quake](https://github.com/phodal/quake)|Quake is a knowledge management meta-framework for geeks. Use meta-data + Transflow to CRUD data,  Git + markdown to management content, Web Component for frontend-custom. Quake 是面向极客的知识管理元框架。|353|Rust|2022-07-12|2021-11-17|
|58|[threeknowbigdata/flink_second_understand](https://github.com/threeknowbigdata/flink_second_understand)|该仓库专注于让读者秒懂Flink组件，包含Flink实战代码和文档、200个Flink教程知识点，Flink Datastream、Flink Table、Flink Window、Flink State、Flink Checkpoint、Flink Metrics、Flink Memory、Flink on standalone /yarn/k8s、Flink SQL、Flink CEP、Fli ...|350|Java|2022-07-03|2021-10-23|
|59|[cxOrz/chaoxing-sign-cli](https://github.com/cxOrz/chaoxing-sign-cli)|超星学习通签到Nodejs程序。支持普通签到、拍照签到、手势签到、位置签到、二维码签到，支持自动监测。|342|JavaScript|2022-08-01|2021-10-25|
|60|[Petit-Abba/backup_script_zh-CN](https://github.com/Petit-Abba/backup_script_zh-CN)|数据备份脚本 简体中文版|339|Shell|2022-05-15|2021-09-08|
|61|[luckyzhz/Software-Designer](https://github.com/luckyzhz/Software-Designer)|软考中级教程-软件设计师|335|HTML|2022-04-13|2021-12-22|
|62|[fantasticit/think](https://github.com/fantasticit/think)|云策文档是一款开源知识管理工具。通过独立的知识库空间，结构化地组织在线协作文档，实现知识的积累与沉淀，促进知识的复用与流通。|330|JavaScript|2022-05-24|2022-02-20|
|63|[SummerSec/SpringExploit](https://github.com/SummerSec/SpringExploit)|🚀 一款为了学习go而诞生的漏洞利用工具|310|Go|2022-06-14|2022-04-19|
|64|[splitline/How-to-Hack-Websites](https://github.com/splitline/How-to-Hack-Websites)|開源的正體中文 Web Hacking 學習資源 - 程式安全 2021 Fall|299|PHP|2022-03-21|2021-11-09|
|65|[gm365/Web3_Tutorial](https://github.com/gm365/Web3_Tutorial)|🐳 Web3科学家极简入门指南|281|Python|2022-05-25|2022-05-20|
|66|[tnfe/shida](https://github.com/tnfe/shida)|《视搭》是一个视频可视化搭建项目。您可以通过简单的拖拽方式快速生产一个短视频，使用方式就像易企秀或百度 H5 等 h5 搭建工具一样的简单，仅抛砖引玉希望您喜欢。|270|Vue|2022-06-20|2022-01-15|
|67|[note286/xdupgthesis](https://github.com/note286/xdupgthesis)|西安电子科技大学研究生学位论文XeLaTeX模板|250|TeX|2022-03-27|2021-10-15|
|68|[dtm-labs/dtf](https://github.com/dtm-labs/dtf)|大家好，dtm最终跟原公司谈下来了知识产权转让，现已恢复维护，请大家访问 https://github.com/dtm-labs/dtm 。中间给大家带来的不便，敬请谅解！|249|Go|2022-03-29|2022-03-04|
|69|[kahowang/sensor-fusion-for-localization-and-mapping](https://github.com/kahowang/sensor-fusion-for-localization-and-mapping)|深蓝学院 多传感器定位融合第四期 学习笔记|248|C++|2022-05-20|2021-08-15|
|70|[jincheng9/go-tutorial](https://github.com/jincheng9/go-tutorial)|Go learning materials，涵盖基础、中级和高级教程|242|Go|2022-08-02|2021-10-19|
|71|[zhaohongxuan/obsidian-weread-plugin](https://github.com/zhaohongxuan/obsidian-weread-plugin)|Obsidian Weread Plugin is a plugin to sync Weread(微信读书) hightlights and annotations into your Obsidian Vault.|236|TypeScript|2022-07-30|2022-05-08|
|72|[sec-an/Better-Auto-XXQG](https://github.com/sec-an/Better-Auto-XXQG)|学习强国 基于Auto.js实现的学习助手 免root 适配安卓 自动化脚本 热更新|236|JavaScript|2022-07-21|2022-02-14|
|73|[AlphabugX/csOnvps](https://github.com/AlphabugX/csOnvps)|CobaltStrike4.4 一键部署脚本 随机生成密码、key、端口号、证书等，解决cs4.x无法运行在Linux上报错问题 灰常银杏化设计|234|Shell|2022-03-19|2021-12-02|
|74|[sqlsec/Hackintosh](https://github.com/sqlsec/Hackintosh)|国光的黑苹果安装教程：手把手教你配置 OpenCore|224|HTML|2022-05-06|2021-09-15|
|75|[wangzhe3224/awesome-systematic-trading](https://github.com/wangzhe3224/awesome-systematic-trading)|A curated list of insanely awesome libraries, packages and resources for systematic trading. Crypto, Stock, Futures, Options, CFDs, FX, and more   量化交易   量化投资|223|Rust|2022-07-31|2021-12-11|
|76|[rustlang-cn/rust-algos](https://github.com/rustlang-cn/rust-algos)|<<Rust算法题解>>，用Rust语言实现常见的算法和数据结构，以及leetcode题解，algos = algorithms，written with ❤️ by course.rs team|221|Rust|2022-07-05|2021-12-02|
|77|[canliture/nju-software-analysis-homework](https://github.com/canliture/nju-software-analysis-homework)|南京大学《软件分析》课程课后作业(非Bamboo)   NJU's software analysis homework; ... Not official, just a reference|220|Java|2022-05-14|2021-10-09|
|78|[overmind1980/oeasypython](https://github.com/overmind1980/oeasypython)|面向初学者的简明易懂的 Python3 课程，对没有编程经验的同学也非常友好。在vim下从浅入深，逐步学习。|218|Shell|2022-05-11|2021-08-04|
|79|[LookCos/learn-data-structures](https://github.com/LookCos/learn-data-structures)|数据结构（C语言描述）学习笔记|193|C|2022-03-12|2021-10-09|
|80|[sari3l/sams_helper](https://github.com/sari3l/sams_helper)|山姆全自动抢购：普通商品、保供套餐；支持优惠券、无货添加、数量修正、金额限制、超重拆分、黑白名单|181|Go|2022-06-01|2022-04-14|
|81|[teamssix/twiki](https://github.com/teamssix/twiki)|T Wiki 云安全知识文库，可能是国内首个云安全知识文库？|168|HTML|2022-05-13|2022-04-15|
|82|[sunface/fancy-rust](https://github.com/sunface/fancy-rust)|Rust酷库推荐 - 使用我们精心挑选的开源代码，让你的Rust项目Fancy起来!    Written with ❤️ by course.rs team|161|Rust|2022-02-18|2021-12-29|
|83|[fltenwall/web3-awesome](https://github.com/fltenwall/web3-awesome)|web3百科全书👏🏻 打造 web3 全球第一中文资源|157|HTML|2022-05-13|2022-04-14|
|84|[haoxie666/HxMinerProxy](https://github.com/haoxie666/HxMinerProxy)|HXMinerProxy/ETH/ETC/BTC/BCH/CFX/RVN/ERG/LTC/SERO/XMR中转矿池代理支持抽水,软件防CC,支持BTC/ETH/ETC/BCH/CFX/ERG/RVN/LTC/SERO/XMR无损耗抽水,支持TCP和SSL协议，支持自定义跨矿池抽水，高性能高并发，支持web界面管理，不爆内存,全自动进程守护以及开机启动,配套本地隧道加密软件，修改矿池本地算力，ip黑 ...|157|Go|2022-08-01|2022-04-05|
|85|[johlanse/study_xxqg](https://github.com/johlanse/study_xxqg)|自动化学习强国,每日稳定45分|156|Go|2022-08-02|2021-11-12|
|86|[heiyeluren/xds](https://github.com/heiyeluren/xds)|A third-party extensible collection of high-performance data structures and data types in Go. 第三方可扩展的Go语言中高性能数据结构和数据类型合集|153|Go|2022-06-07|2022-02-25|
|87|[lanbao2021/share](https://github.com/lanbao2021/share)|分享蓝同学收集的软件资源、使用心得...|144|HTML|2022-07-07|2022-02-11|
|88|[RyensX/MediaBox](https://github.com/RyensX/MediaBox)|插件化媒体容器，不含广告，免费开源，便于学习Android开发。A media container for extending content through plug-ins, no ads, free and open source, easy to learn Android development.|140|Kotlin|2022-08-02|2022-02-13|
|89|[jaywcjlove/regexp-example](https://github.com/jaywcjlove/regexp-example)|正则表达式实例搜集，通过实例来学习正则表达式。|131|HTML|2022-07-12|2021-11-15|
|90|[yanzhandong/v3hooks](https://github.com/yanzhandong/v3hooks)|针对 Vue3 的实用Hooks集合|131|TypeScript|2022-05-16|2021-08-05|
|91|[YunYouJun/valaxy](https://github.com/YunYouJun/valaxy)|🌌 Next Generation Static Blog Framework (Beta) 下一代静态博客框架（支持页面/配置热重载）|128|TypeScript|2022-08-02|2022-03-08|
|92|[fuzhengwei/CodeDesignTutorials](https://github.com/fuzhengwei/CodeDesignTutorials)|:art: 《重学Java设计模式》是一本互联网真实案例实践书籍。以落地解决方案为核心，从实际业务中抽离出，交易、营销、秒杀、中间件、源码等22个真实场景，来学习设计模式的运用。欢迎关注小傅哥，微信(fustack)，公众号：bugstack虫洞栈，博客：https://bugstack.cn|125|Java|2022-06-08|2022-02-19|
|93|[vitest-dev/docs-cn](https://github.com/vitest-dev/docs-cn)|Vitest 中文文档|125|TypeScript|2022-08-02|2022-02-12|
|94|[LightNovelShelf/Web](https://github.com/LightNovelShelf/Web)|轻书架的下个主要版本|121|Vue|2022-08-01|2021-08-22|
|95|[algorithmzuo/weekly-problems](https://github.com/algorithmzuo/weekly-problems)|每周有营养的大厂算法面试题（直播进行中，每周三晚上8点）|120|Java|2022-07-29|2021-11-22|
|96|[rootsongjc/opentelemetry-obervability](https://github.com/rootsongjc/opentelemetry-obervability)|《OpenTelemetry 可观测性的未来》  O'Reilly 报告 |118|Shell|2022-05-19|2022-02-05|
|97|[Isayama-Kagura/TsubakiTranslator](https://github.com/Isayama-Kagura/TsubakiTranslator)|一款Galgame文本提取和翻译的工具|114|C#|2022-04-16|2021-09-21|
|98|[linbudu599/TypeScript-Tiny-Book](https://github.com/linbudu599/TypeScript-Tiny-Book)|掘金小册「TypeScript 全面进阶指南」示例代码，余杭区最好的 TypeScript 教程！|109|TypeScript|2022-08-01|2022-05-20|
|99|[marmotedu/goserver](https://github.com/marmotedu/goserver)|教你快速开发一个企业级的Go后端服务（教程 + 代码；Go入门项目）|108|Go|2022-02-09|2022-01-29|
|100|[Deali-Axy/StarBlog](https://github.com/Deali-Axy/StarBlog)|☀☀支持Markdown导入的博客。后端基于最新的.Net6和Asp.Net Core框架，遵循RESTFul接口规范，前端基于Vue+ElementUI开发，可作为 .Net Core 入门项目学习~|105|C#|2022-07-27|2022-02-15|
|101|[shibing624/nlp-tutorial](https://github.com/shibing624/nlp-tutorial)|自然语言处理（NLP）教程，包括：词向量，词法分析，预训练语言模型，文本分类，文本语义匹配，信息抽取，翻译，对话。|104|Jupyter Notebook|2022-05-07|2021-08-06|
|102|[crithes/gaojieDoc](https://github.com/crithes/gaojieDoc)|crithesJie的博客文档|103|HTML|2022-05-18|2022-02-28|
|103|[Misaka-blog/acme-1key](https://github.com/Misaka-blog/acme-1key)|Acme.sh 域名证书一键申请脚本|102|Shell|2022-05-01|2021-12-31|
|104|[binghe001/BingheGuide](https://github.com/binghe001/BingheGuide)|📚 本代码库是作者冰河多年从事互联网大厂开发、架构的学习历程技术汇总，旨在为大家提供一个清晰详细的学习教程，侧重点更倾向编写Java核心内容、底层原理、架构知识、渗透技术。如果本仓库能为您提供帮助，请给予支持(关注、点赞、分享)！|94|Shell|2022-07-25|2022-03-31|
|105|[ymm135/golang-cookbook](https://github.com/ymm135/golang-cookbook)|golang基础知识及实现，偏重于数据结构。另外包含web开源项目(中间件)的日常使用|94|Go|2022-07-15|2021-11-20|
|106|[superleeyom/my-feed-OPML](https://github.com/superleeyom/my-feed-OPML)|分享我订阅的一些 Blog 和 Newsletter，通过 Github Actions，每天自动同步我 Feedly 上的订阅源，✅ 代表能正常订阅，❌ 代表暂无法订阅（对于无法订阅的 feed，支持 Telegram Bot、Email、Server酱等推送工具提醒更新）|92|Java|2022-07-04|2022-03-29|
|107|[sanyuan0704/juejin-book-vite](https://github.com/sanyuan0704/juejin-book-vite)|《深入浅出 Vite》掘金小册代码示例仓库|92|HTML|2022-05-15|2021-12-17|
|108|[bkfish/Apache-Log4j-Learning](https://github.com/bkfish/Apache-Log4j-Learning)|Apache-Log4j漏洞复现笔记|91|Java|2022-02-17|2021-12-10|
|109|[bigwhite/GoProgrammingFromBeginnerToMaster](https://github.com/bigwhite/GoProgrammingFromBeginnerToMaster)|Go语言精进之路书籍配套代码|85|Go|2022-08-02|2021-12-17|
|110|[WENZIZZHENG/spring-boot-demo](https://github.com/WENZIZZHENG/spring-boot-demo)|Spring Boot 教程、技术栈示例代码。在工作中的最佳实践，帮助快速上手运用到工作中。|83|Java|2022-02-08|2021-11-27|
|111|[shouxieai/learning-cuda-trt](https://github.com/shouxieai/learning-cuda-trt)|A large number of cuda/tensorrt cases . 大量案例来学习cuda/tensorrt|82|C++|2022-07-24|2022-07-24|
|112|[realYurkOfGitHub/translation-Introduction-to-HPC](https://github.com/realYurkOfGitHub/translation-Introduction-to-HPC)|为 Eijhout 教授的Introduction to HPC提供中文翻译、 PPT和Lab。|82|C|2022-04-11|2021-10-18|
|113|[yitd/wxkp](https://github.com/yitd/wxkp)|微信卡片分享链接在线制作工具|80|CSS|2022-05-30|2021-08-14|
|114|[feiskyer/ebpf-apps](https://github.com/feiskyer/ebpf-apps)|极客时间专栏《eBPF 核心技术与实战》案例|79|C|2022-04-05|2021-11-01|
|115|[fanfansann/fanfan-deep-learning-note](https://github.com/fanfansann/fanfan-deep-learning-note)|《繁凡的深度学习笔记》代码、PDF文件仓库|77|Jupyter Notebook|2022-02-15|2021-10-20|
|116|[Wsine/feishu2md](https://github.com/Wsine/feishu2md)|一键命令下载飞书文档为 Markdown|75|Go|2022-07-22|2022-05-16|
|117|[uiuing/VARBook](https://github.com/uiuing/VARBook)|适合中文程序员的变量命名助手，NLP+翻译，规范变量命名，定制化变量命名规则|75|HTML|2022-07-20|2021-12-30|
|118|[gaowei-space/markdown-blog](https://github.com/gaowei-space/markdown-blog)|🍭 Markdown-Blog 是一款小而美的Markdown静态博客程序|74|Go|2022-07-31|2022-05-21|
|119|[julydate/acmeDeliver](https://github.com/julydate/acmeDeliver)|acme.sh 证书分发服务|72|Go|2022-05-08|2022-01-21|
|120|[zkwlx/SimpleWalker](https://github.com/zkwlx/SimpleWalker)|知乎 Android 团队使用的静态代码检查工具，支持目录、.apk、.dex、.jar、.aar 格式，可通过配置文件添加检查策略。 主要用于检查 Android 应用或依赖库是否有调用隐私接口。|71|Java|2022-04-21|2021-09-15|
|121|[doodlewind/learn-wgpu-cn](https://github.com/doodlewind/learn-wgpu-cn)|🇨🇳 《Learn Wgpu》中文版|70|Rust|2022-04-30|2022-04-23|
|122|[pandengyang/peach](https://github.com/pandengyang/peach)|桃花源（英文名为 peach）是一个迷你虚拟机，用于学习 Intel 硬件虚拟化技术。|70|C|2022-03-19|2022-03-19|
|123|[fuqiuluo/TXHook](https://github.com/fuqiuluo/TXHook)|腾讯QQ协议分析工具，为了推进学习与研究，可加群：702991373|69|Java|2022-08-01|2021-09-24|
|124|[fine-1/php-SER-libs](https://github.com/fine-1/php-SER-libs)|php反序列化靶场，集合了常见的php反序列化漏洞——由这周末在做梦制作|66|PHP|2022-03-18|2022-03-18|
|125|[3rsh1/goBypassAv](https://github.com/3rsh1/goBypassAv)|一个持续收集和学习bypassAv技术的golang实现的仓库|66|Go|2022-03-12|2022-03-07|
|126|[howie6879/weekly](https://github.com/howie6879/weekly)|老胡的周刊❤️记录我本周看到的有价值的信息，针对优秀项目、软件、教程资料、网站等。|66|HTML|2022-08-01|2021-09-17|
|127|[Adicwu/comic-pc](https://github.com/Adicwu/comic-pc)|一个仅供学习自用的PC端动漫视频网站|65|Vue|2022-07-28|2022-03-01|
|128|[idinr/photography-blog](https://github.com/idinr/photography-blog)|photography blog generator - 摄影类静态博客生成器|64|CSS|2022-07-25|2022-05-23|
|129|[NJUPTFreeExams/NJUPT-CS-FREE](https://github.com/NJUPTFreeExams/NJUPT-CS-FREE)|南京邮电大学计软网安院学习资料。Covers all materials for CST, SE, and InfoSec majors.|64|HTML|2022-06-21|2021-08-29|
|130|[ncghost1/MassDataProcessingLab](https://github.com/ncghost1/MassDataProcessingLab)|海量数据处理经典面试题的 Go 语言实现，此外还提供 lab 来亲身实践~ Golang implementation of classical interview questions of mass data processing, also provide lab for you to practice. |63|Go|2022-07-01|2022-06-27|
|131|[rootsongjc/envoy-handbook](https://github.com/rootsongjc/envoy-handbook)|Envoy 基础教程 - https://jimmysong.io/envoy-handbook/|61|Shell|2022-05-02|2022-03-01|
|132|[eddycjy/go-design-book](https://github.com/eddycjy/go-design-book)|《Go 语言设计哲学》|57|HTML|2022-05-04|2021-12-26|
|133|[serfend/problem-killer](https://github.com/serfend/problem-killer)|自定义题库的刷题工具软件|56|Vue|2022-06-09|2022-04-29|
|134|[hunterzju/llvm-tutorial](https://github.com/hunterzju/llvm-tutorial)|llvm-tutorial文档，翻译以及代码仓库|56|C++|2022-02-20|2021-11-01|
|135|[AccumulateMore/CPlusPlus](https://github.com/AccumulateMore/CPlusPlus)|最全面的 C++ 笔记|56|Jupyter Notebook|2022-07-23|2021-08-07|
|136|[su37josephxia/frontend-interview](https://github.com/su37josephxia/frontend-interview)|前端面试知识点|55|HTML|2022-02-06|2021-09-03|
|137|[calebman/girlfriend-gift-collection](https://github.com/calebman/girlfriend-gift-collection)|送给女朋友的礼物合集，生日/情人节/纪念日等，程序员的创意。|54|CSS|2022-02-11|2022-02-10|
|138|[NianBroken/Firework_Simulator](https://github.com/NianBroken/Firework_Simulator)|烟花模拟器，一个模拟放烟花的网页，基于XgpNwb的二次修改，我仅作翻译处理以及其他优化|52|HTML|2022-02-03|2022-01-30|
|139|[DDWSdwqdq/VNREX](https://github.com/DDWSdwqdq/VNREX)|GAL翻译器、离线OCR、离线TTS|51|C#|2022-04-14|2021-12-27|
|140|[diylove/wiki](https://github.com/diylove/wiki)|从diy行为艺术到diy苏格拉底式对话，从diy一个仪式到diy一次旷课，各种活动指南的百科。diy💔是706孵化的一个非代码开源项目。|49|Ruby|2022-05-21|2021-08-22|
|141|[ohnonoyesyes/zsxq_dl](https://github.com/ohnonoyesyes/zsxq_dl)|星球伴侣（无限下载版） - 知识星球助手|48|HTML|2022-02-26|2022-02-26|
|142|[huanlin/LearningNotes](https://github.com/huanlin/LearningNotes)|學習筆記，主要是 C# 與 .NET 技術。|48|C#|2022-04-21|2022-02-08|
|143|[viewweiwu/v2ex-zhihu-theme](https://github.com/viewweiwu/v2ex-zhihu-theme)|v2ex 知乎 主题样式|48|CSS|2022-06-02|2021-12-06|
|144|[xieliaing/CausalInferenceIntro](https://github.com/xieliaing/CausalInferenceIntro)|Causal Inference for the Brave and True的中文翻译版。全部代码基于Python，适用于计量经济学、量化社会学、策略评估等领域。英文版原作者：Matheus Facure|48|Jupyter Notebook|2022-04-16|2021-11-07|
|145|[ZGQ-inc/source](https://github.com/ZGQ-inc/source)|个人搜集   书源、图源、订阅源、规则、直播源、各种源 大型整合|43|HTML|2022-08-01|2022-04-20|
|146|[UserZYF/zhang-light](https://github.com/UserZYF/zhang-light)|思源笔记的一款主题|43|CSS|2022-05-25|2022-02-11|
|147|[liuzhijun-source/spacemacs-14-days](https://github.com/liuzhijun-source/spacemacs-14-days)|一个 Spacemacs 的入门教程|43|HTML|2022-04-10|2021-09-20|
|148|[acdzh/douban-book-api](https://github.com/acdzh/douban-book-api)|第三方豆瓣读书 api 接口|43|HTML|2022-05-18|2021-08-22|
|149|[ADKcodeXD/Myblog-Vue3viteTs](https://github.com/ADKcodeXD/Myblog-Vue3viteTs)|我的个人博客，使用vue3+vite+Ts搭建 ，后台正在搭建中，使用java springboot|41|Vue|2022-07-20|2022-02-13|
|150|[datawhalechina/hands-dirty-nlp](https://github.com/datawhalechina/hands-dirty-nlp)|本课程面对具有一定机器学习基础，但尚未入门的NLPer或经验尚浅的NLPer，尽力避免陷入繁琐枯燥的公式讲解中，力求用代码展示每个模型背后的设计思想，同时也会带大家梳理每个模块下的技术演变，做到既知树木也知森林。|41|Jupyter Notebook|2022-02-19|2021-12-15|
|151|[bamboo512/ModernChineseDict](https://github.com/bamboo512/ModernChineseDict)|《现代汉语词典》第 7 版的 mdict/mdx 资源。|40|CSS|2022-04-08|2022-02-28|
|152|[buynao/stackoverflow-js-top-qa](https://github.com/buynao/stackoverflow-js-top-qa)|stackoverflow上javascript热门回答整理翻译|40|HTML|2022-04-17|2022-02-12|
|153|[Littlefean/SmartPython](https://github.com/Littlefean/SmartPython)|python小技巧系列源代码——来自b站视频|39|HTML|2022-07-14|2022-06-17|
|154|[zui0711/Z-Lab](https://github.com/zui0711/Z-Lab)|Z Lab数据实验室开源代码汇总|39|Jupyter Notebook|2022-06-26|2021-12-30|
|155|[qinxs/Ease-Bookmarks](https://github.com/qinxs/Ease-Bookmarks)|简单易用的书签管理器|39|HTML|2022-03-14|2021-12-04|
|156|[mixmoe/HikariSearch](https://github.com/mixmoe/HikariSearch)|一款动漫图片搜索引擎聚合网站, 基于 Cloudflare 提供的 Pages Function. / A collection of anime image search engines, based on Cloudflare Pages Function.|38|Vue|2022-07-26|2022-02-20|
|157|[leavesCZY/RobustWebView](https://github.com/leavesCZY/RobustWebView)|Android WebView H5 秒开方案总结|37|Kotlin|2022-02-28|2021-09-12|
|158|[xloger/LawRefBookAndroid](https://github.com/xloger/LawRefBookAndroid)|中华人民共和国法律手册 - 一个 Android 端的阅读器|34|Kotlin|2022-07-04|2022-03-20|
|159|[ECNU-ICA/ECNU_graduation_thesis_template](https://github.com/ECNU-ICA/ECNU_graduation_thesis_template)|华东师范大学研究生毕业论文 Latex 模板|34|TeX|2022-03-22|2021-11-17|
|160|[rootsongjc/developer-advocacy-handbook](https://github.com/rootsongjc/developer-advocacy-handbook)|开发者布道手册 - https://jimmysong.io/developer-advocacy-handbook/|33|Shell|2022-03-25|2022-03-15|
|161|[L-zhicong/blog-vue](https://github.com/L-zhicong/blog-vue)|博客前端|32|Vue|2022-05-25|2022-04-11|
|162|[wangyupo/vue3-cookbook](https://github.com/wangyupo/vue3-cookbook)|vue3 组合式API、vuex、vue-router、axios、tailwindcss使用示例及代码展示，vue3 入门参考书，vue3 烹饪书 |32|Vue|2022-04-08|2022-03-10|
|163|[xiaoweiChen/LLVM-Techniques-Tips-and-Best-Practies](https://github.com/xiaoweiChen/LLVM-Techniques-Tips-and-Best-Practies)|《LLVM Techniques, Tips, and Best Practices》的非专业个人翻译|31|TeX|2022-02-03|2022-01-01|
|164|[bcaso/Computer-Science-Whitelist](https://github.com/bcaso/Computer-Science-Whitelist)|Google 搜索结果中垃圾站点越来越多，于是这个白名单就这么出来了。|31|Jupyter Notebook|2022-07-25|2021-11-10|
|165|[zburu/Anghunk](https://github.com/zburu/Anghunk)|Anghunk一款基于Typecho博客程序的主题，简单整洁是主色调。|30|PHP|2022-08-02|2022-04-09|
|166|[justorez/bookmark-cleaner](https://github.com/justorez/bookmark-cleaner)|自动检测失效书签链接，一键清理 🚀|30|Vue|2022-05-04|2022-04-05|
|167|[MikesWei/wechat-blog](https://github.com/MikesWei/wechat-blog)|分享Cesium、three.js等开发技术使用心得、经验，附带一些源码|30|HTML|2022-02-23|2021-09-16|
|168|[cumt-robin/vue3-ts-blog-frontend](https://github.com/cumt-robin/vue3-ts-blog-frontend)|基于 vue3 + ts + ant-design-vue 的个人博客|30|Vue|2022-06-28|2021-08-19|
|169|[tomstillcoding/tomstillcoding.github.io](https://github.com/tomstillcoding/tomstillcoding.github.io)|🎙️这是一个通过 jekyll + GitHub Pages 搭建的个人免费博客，可以通过 fork + 改造 + 用 Typora 编写文章的方法，打造你的个人博客。特点是方便、快捷，从搭建到发布第一篇文章、访问，3分钟内解决，甚至不用写任何一行代码，博客网页内容完全自定义、无广告、无注册，各种插件免费安装！|29|Shell|2022-05-01|2022-03-26|
|170|[imhlq/EldenRingCheatSheetCN](https://github.com/imhlq/EldenRingCheatSheetCN)|艾尔登法环实用手册项目 Checklist Cheatsheet|29|HTML|2022-07-03|2022-03-14|
|171|[Creator-SN/IKFB](https://github.com/Creator-SN/IKFB)|Involution King Fun Book (IKFB, Chinese: 快卷, 卷王快乐本) is an integrated management system for papers and literature. Powered by Electron.|29|Vue|2022-05-26|2021-09-20|
|172|[easyhappy/travel-coding](https://github.com/easyhappy/travel-coding)|公众号: 漫步coding, 一个分享数据库、算法、架构一些心得的公众号|28|Shell|2022-07-10|2022-03-20|
|173|[sicong-li/T.vim](https://github.com/sicong-li/T.vim)|一个提供英-中翻译的vim插件|28|Vim script|2022-02-10|2022-02-09|
|174|[nice-people-frontend-community/nice-leetcode](https://github.com/nice-people-frontend-community/nice-leetcode)|好青年    leetcode 打卡群|27|Vue|2022-08-02|2022-05-03|
|175|[Justin02180218/blockchain_rust](https://github.com/Justin02180218/blockchain_rust)|本系列是用Rust实现简单的区块链，包括区块和区块链，工作量证明，交易和UTXO集合，持久化，钱包及用rust-libp2p实现的点对点分布式网络。|27|Rust|2022-04-24|2022-04-19|
|176|[Brx86/DingZhen](https://github.com/Brx86/DingZhen)|一眼丁真合集与Api，目前已收集502张|27|HTML|2022-05-12|2022-04-02|
|177|[nilaoda/OneDriveShareLinkParser](https://github.com/nilaoda/OneDriveShareLinkParser)|从OneDrive分享链接获取并推送下载地址到IDM以进行批量下载. Push To IDM.|27|C#|2022-02-19|2022-02-10|
|178|[CnGal/CnGalWebSite](https://github.com/CnGal/CnGalWebSite)|CnGal是一个非营利性的，立志于收集整理国内制作组创作的中文Galgame/AVG的介绍、攻略、评测、感想等内容的资料性质的网站。|27|C#|2022-07-23|2021-12-06|
|179|[xingxi521/vue-blog-community](https://github.com/xingxi521/vue-blog-community)|vue社区博客-vue全家桶-koa2-mongoose-mongoDB|25|Vue|2022-05-25|2022-02-13|
|180|[jones2000/HQChart-Super](https://github.com/jones2000/HQChart-Super)|HQChart对接第3放数据教程.|25|Vue|2022-06-27|2021-10-11|
|181|[linuxhitchhiker/THGLG](https://github.com/linuxhitchhiker/THGLG)|The Hitchhiker's Guide to the Linux : Linux 漫游指南|24|HTML|2022-05-18|2022-01-15|
|182|[simplismvip/SRBook](https://github.com/simplismvip/SRBook)|电子书阅读器，支持epub和txt格式|24|Swift|2022-03-22|2021-10-19|
|183|[flaribbit/vitepress-theme-sakura](https://github.com/flaribbit/vitepress-theme-sakura)|A lovely blog theme for vitepress. 可爱又轻量的二次元博客主题！大概是隔壁 wordpress sakura 主题的移植吧|23|Vue|2022-06-20|2022-02-10|
|184|[Jy-stdio/2021-ICM-D-Outstanding](https://github.com/Jy-stdio/2021-ICM-D-Outstanding)|2021 数模美赛O奖论文及代码公开 |23|TeX|2022-02-17|2022-01-01|
|185|[damit5/damit5.github.io](https://github.com/damit5/damit5.github.io)|个人部分知识总结|23|HTML|2022-06-25|2021-12-18|
|186|[Zuoqiu-Yingyi/siyuan-theme-dark-plus](https://github.com/Zuoqiu-Yingyi/siyuan-theme-dark-plus)|思源笔记的一款双色主题(A bicolor theme of SiYuan Note)|22|CSS|2022-04-09|2021-12-24|
|187|[HuRuWo/HowToReserveFlutter](https://github.com/HuRuWo/HowToReserveFlutter)|HowToReserveFlutter is some  reverse flutter note 。flutter逆向笔记，如何一步一步分析 flutter apk。|22|Dart|2022-04-02|2021-12-20|
|188|[note286/xduugtp](https://github.com/note286/xduugtp)|西安电子科技大学本科生毕业论文（设计）开题报告LaTeX模板|21|TeX|2022-03-09|2022-01-02|
|189|[daodaolee/vuepress-plugin-awesome-musicplayer](https://github.com/daodaolee/vuepress-plugin-awesome-musicplayer)|一款基于vuepress1.x插件的音乐播放器，打破以往博客音乐播放方式，让用户有更佳的沉浸式体验！|21|Vue|2022-03-27|2021-12-23|
|190|[tianxily/free](https://github.com/tianxily/free)|每天免费分享Clash，V2ray，包含ss，trojan，vmess等主流格式，TG搜索@tianxifree，记得把Star点亮|20|HTML|2022-07-01|2022-02-14|
|191|[lvyufeng/d2l-mindspore](https://github.com/lvyufeng/d2l-mindspore)|《动手学深度学习》的MindSpore实现。供MindSpore学习者配合李沐老师课程使用。|20|Jupyter Notebook|2022-02-02|2021-10-28|
|192|[note286/xdupgtp](https://github.com/note286/xdupgtp)|西安电子科技大学研究生学位论文开题报告表XeLaTeX模板|19|TeX|2022-03-18|2021-12-31|
|193|[arect/onedrive_blog](https://github.com/arect/onedrive_blog)|OneDrive/Blog 以OneDrive为储存的博客“引擎”|19|CSS|2022-07-26|2021-12-10|
|194|[crazybox521/vue-NetEasyMusic](https://github.com/crazybox521/vue-NetEasyMusic)|基于vue和开源网易云音乐node接口的仿网易云音乐网站，音乐和视频相关内容几乎都已完成，仅供学习交流|18|Vue|2022-07-24|2021-12-21|
|195|[Dreamer-Paul/Hingle](https://github.com/Dreamer-Paul/Hingle)|🎈 一个简洁大气，含夜间模式的 Hexo 博客主题|18|CSS|2022-03-10|2021-10-24|
|196|[Zhao-666/CodeFPS](https://github.com/Zhao-666/CodeFPS)|Use Unity3D engine to develop a FPS game that imition COD4 Traing Area. 使用Unity引擎实现的一款FPS游戏，实现《使命召唤4》训练靶场关卡|18|C#|2022-02-13|2021-10-12|
|197|[MeouSker77/ProgrammingRust](https://github.com/MeouSker77/ProgrammingRust)|本书为《Programming Rust - Fast, Safe Systems Development》第2版的个人中文翻译，仅供学习和交流使用，如有侵权请联系作者删除|18|TeX|2022-03-04|2021-10-01|
|198|[Okarin1/web-project](https://github.com/Okarin1/web-project)|A minimalist static bookmark！|17|Vue|2022-07-15|2022-01-21|
|199|[hinesboy/SUDA-Latex](https://github.com/hinesboy/SUDA-Latex)|苏州大学-硕士毕业大论文-Latex模版（附安装使用说明）|17|TeX|2022-03-22|2022-01-06|
|200|[JiaYang627/QuickAndroid](https://github.com/JiaYang627/QuickAndroid)|:octocat:使用Kotlin搭建的一个基础框架。目的旨在学习Kotlin，更好的从Java过渡到Kotlin，并且针对此项目编写了一键生成页面插件。具体可看README:book:|17|Kotlin|2022-07-05|2021-12-01|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
