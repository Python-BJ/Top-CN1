<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > C#
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[wmjordan/PDFPatcher](https://github.com/wmjordan/PDFPatcher)|PDF补丁丁——PDF工具箱，可以编辑书签、剪裁旋转页面、解除限制、提取或合并文档，探查文档结构，提取图片、转成图片等等|6070|2022-07-22|2021-12-24|
|2|[Isayama-Kagura/TsubakiTranslator](https://github.com/Isayama-Kagura/TsubakiTranslator)|一款Galgame文本提取和翻译的工具|114|2022-04-16|2021-09-21|
|3|[Deali-Axy/StarBlog](https://github.com/Deali-Axy/StarBlog)|☀☀支持Markdown导入的博客。后端基于最新的.Net6和Asp.Net Core框架，遵循RESTFul接口规范，前端基于Vue+ElementUI开发，可作为 .Net Core 入门项目学习~|105|2022-07-27|2022-02-15|
|4|[DDWSdwqdq/VNREX](https://github.com/DDWSdwqdq/VNREX)|GAL翻译器、离线OCR、离线TTS|51|2022-04-14|2021-12-27|
|5|[huanlin/LearningNotes](https://github.com/huanlin/LearningNotes)|學習筆記，主要是 C# 與 .NET 技術。|48|2022-04-21|2022-02-08|
|6|[nilaoda/OneDriveShareLinkParser](https://github.com/nilaoda/OneDriveShareLinkParser)|从OneDrive分享链接获取并推送下载地址到IDM以进行批量下载. Push To IDM.|27|2022-02-19|2022-02-10|
|7|[CnGal/CnGalWebSite](https://github.com/CnGal/CnGalWebSite)|CnGal是一个非营利性的，立志于收集整理国内制作组创作的中文Galgame/AVG的介绍、攻略、评测、感想等内容的资料性质的网站。|27|2022-07-23|2021-12-06|
|8|[Zhao-666/CodeFPS](https://github.com/Zhao-666/CodeFPS)|Use Unity3D engine to develop a FPS game that imition COD4 Traing Area. 使用Unity引擎实现的一款FPS游戏，实现《使命召唤4》训练靶场关卡|18|2022-02-13|2021-10-12|
|9|[liamwang/geekgist](https://github.com/liamwang/geekgist)|『.NET 大牛之路』课程实战项目，一个电子书分享网站|9|2022-05-19|2021-10-21|
|10|[yui-10497108108111/MD-CN-Translator](https://github.com/yui-10497108108111/MD-CN-Translator)|游戏王 master duel 翻译工具|7|2022-02-23|2022-01-23|
|11|[xiuluo211314/Note163Checkin](https://github.com/xiuluo211314/Note163Checkin)|本项目是基于Github Actions的有道云笔记每日定时任务签到（主要重写了项目Note163Checkin ）。每日可新增30M+存储空间。|4|2022-07-24|2022-07-14|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
