<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Java
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[krahets/LeetCode-Book](https://github.com/krahets/LeetCode-Book)|《剑指 Offer》 Python, Java, C++ 解题代码，LeetBook《图解算法数据结构》配套代码仓。|905|2022-02-21|2021-12-17|
|2|[threeknowbigdata/flink_second_understand](https://github.com/threeknowbigdata/flink_second_understand)|该仓库专注于让读者秒懂Flink组件，包含Flink实战代码和文档、200个Flink教程知识点，Flink Datastream、Flink Table、Flink Window、Flink State、Flink Checkpoint、Flink Metrics、Flink Memory、Flink on standalone /yarn/k8s、Flink SQL、Flink CEP、Fli ...|350|2022-07-03|2021-10-23|
|3|[canliture/nju-software-analysis-homework](https://github.com/canliture/nju-software-analysis-homework)|南京大学《软件分析》课程课后作业(非Bamboo)   NJU's software analysis homework; ... Not official, just a reference|220|2022-05-14|2021-10-09|
|4|[fuzhengwei/CodeDesignTutorials](https://github.com/fuzhengwei/CodeDesignTutorials)|:art: 《重学Java设计模式》是一本互联网真实案例实践书籍。以落地解决方案为核心，从实际业务中抽离出，交易、营销、秒杀、中间件、源码等22个真实场景，来学习设计模式的运用。欢迎关注小傅哥，微信(fustack)，公众号：bugstack虫洞栈，博客：https://bugstack.cn|125|2022-06-08|2022-02-19|
|5|[algorithmzuo/weekly-problems](https://github.com/algorithmzuo/weekly-problems)|每周有营养的大厂算法面试题（直播进行中，每周三晚上8点）|120|2022-07-29|2021-11-22|
|6|[superleeyom/my-feed-OPML](https://github.com/superleeyom/my-feed-OPML)|分享我订阅的一些 Blog 和 Newsletter，通过 Github Actions，每天自动同步我 Feedly 上的订阅源，✅ 代表能正常订阅，❌ 代表暂无法订阅（对于无法订阅的 feed，支持 Telegram Bot、Email、Server酱等推送工具提醒更新）|92|2022-07-04|2022-03-29|
|7|[bkfish/Apache-Log4j-Learning](https://github.com/bkfish/Apache-Log4j-Learning)|Apache-Log4j漏洞复现笔记|91|2022-02-17|2021-12-10|
|8|[WENZIZZHENG/spring-boot-demo](https://github.com/WENZIZZHENG/spring-boot-demo)|Spring Boot 教程、技术栈示例代码。在工作中的最佳实践，帮助快速上手运用到工作中。|83|2022-02-08|2021-11-27|
|9|[zkwlx/SimpleWalker](https://github.com/zkwlx/SimpleWalker)|知乎 Android 团队使用的静态代码检查工具，支持目录、.apk、.dex、.jar、.aar 格式，可通过配置文件添加检查策略。 主要用于检查 Android 应用或依赖库是否有调用隐私接口。|71|2022-04-21|2021-09-15|
|10|[fuqiuluo/TXHook](https://github.com/fuqiuluo/TXHook)|腾讯QQ协议分析工具，为了推进学习与研究，可加群：702991373|69|2022-08-01|2021-09-24|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
