<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > JavaScript
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[TechXueXi/techxuexi-js](https://github.com/TechXueXi/techxuexi-js)|油猴等插件的 学习强国 js 代码 45分/天|1773|2022-03-29|2021-10-11|
|2|[dundunnp/auto_xuexiqiangguo](https://github.com/dundunnp/auto_xuexiqiangguo)|每日拿满61分！免root，四人赛双人对战秒答，安卓端学习强国自动化脚本|1452|2022-08-01|2021-11-24|
|3|[BetaSu/fe-hunter](https://github.com/BetaSu/fe-hunter)|每天一道题，3个月后，你就是面试小能手，答题还能赚钱哦|1375|2022-04-22|2022-03-21|
|4|[zkqiang/hangzhou-house-guide](https://github.com/zkqiang/hangzhou-house-guide)|2022年杭州购房指南，根据个人多年购房选房经历，总结而成的一篇买房攻略，涉及新房摇号和二手房选购，包含大量杭州城市规划资料。|760|2022-05-26|2022-03-01|
|5|[eryajf/HowToStartOpenSource](https://github.com/eryajf/HowToStartOpenSource)|⚗️ GitHub开源项目维护协作指南|675|2022-08-02|2022-07-02|
|6|[ttglad/learning](https://github.com/ttglad/learning)|学习强国浏览器插件，自动阅读、观看视频、每日答题、每周答题、专项答题，每日45分！|497|2022-06-24|2021-09-09|
|7|[LeeJim/HowToCookOnMiniprogram](https://github.com/LeeJim/HowToCookOnMiniprogram)|程序员做菜指南 for Miniprogram，将程序员精神贯彻到底|444|2022-05-06|2022-03-01|
|8|[xushengfeng/eSearch](https://github.com/xushengfeng/eSearch)|截屏OCR搜索翻译以图搜图贴图录屏 Screenshot  OCR  search  translate  search for picture  paste the picture on the screen  screen recorder|436|2022-07-29|2021-10-06|
|9|[course-dasheng/fe-algorithm](https://github.com/course-dasheng/fe-algorithm)|前端啃算法，一次性解决前端工程师的算法学习问题|407|2022-07-06|2022-02-22|
|10|[qinhua/halo-theme-joe2.0](https://github.com/qinhua/halo-theme-joe2.0)|🌈 一款 Halo 博客主题 Joe2.0|367|2022-06-03|2021-09-16|
|11|[cxOrz/chaoxing-sign-cli](https://github.com/cxOrz/chaoxing-sign-cli)|超星学习通签到Nodejs程序。支持普通签到、拍照签到、手势签到、位置签到、二维码签到，支持自动监测。|342|2022-08-01|2021-10-25|
|12|[fantasticit/think](https://github.com/fantasticit/think)|云策文档是一款开源知识管理工具。通过独立的知识库空间，结构化地组织在线协作文档，实现知识的积累与沉淀，促进知识的复用与流通。|330|2022-05-24|2022-02-20|
|13|[sec-an/Better-Auto-XXQG](https://github.com/sec-an/Better-Auto-XXQG)|学习强国 基于Auto.js实现的学习助手 免root 适配安卓 自动化脚本 热更新|236|2022-07-21|2022-02-14|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
