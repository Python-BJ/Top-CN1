<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > CSS
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[yitd/wxkp](https://github.com/yitd/wxkp)|微信卡片分享链接在线制作工具|80|2022-05-30|2021-08-14|
|2|[idinr/photography-blog](https://github.com/idinr/photography-blog)|photography blog generator - 摄影类静态博客生成器|64|2022-07-25|2022-05-23|
|3|[calebman/girlfriend-gift-collection](https://github.com/calebman/girlfriend-gift-collection)|送给女朋友的礼物合集，生日/情人节/纪念日等，程序员的创意。|54|2022-02-11|2022-02-10|
|4|[viewweiwu/v2ex-zhihu-theme](https://github.com/viewweiwu/v2ex-zhihu-theme)|v2ex 知乎 主题样式|48|2022-06-02|2021-12-06|
|5|[UserZYF/zhang-light](https://github.com/UserZYF/zhang-light)|思源笔记的一款主题|43|2022-05-25|2022-02-11|
|6|[bamboo512/ModernChineseDict](https://github.com/bamboo512/ModernChineseDict)|《现代汉语词典》第 7 版的 mdict/mdx 资源。|40|2022-04-08|2022-02-28|
|7|[Zuoqiu-Yingyi/siyuan-theme-dark-plus](https://github.com/Zuoqiu-Yingyi/siyuan-theme-dark-plus)|思源笔记的一款双色主题(A bicolor theme of SiYuan Note)|22|2022-04-09|2021-12-24|
|8|[arect/onedrive_blog](https://github.com/arect/onedrive_blog)|OneDrive/Blog 以OneDrive为储存的博客“引擎”|19|2022-07-26|2021-12-10|
|9|[Dreamer-Paul/Hingle](https://github.com/Dreamer-Paul/Hingle)|🎈 一个简洁大气，含夜间模式的 Hexo 博客主题|18|2022-03-10|2021-10-24|
|10|[HurryBy/lanzou-directlink](https://github.com/HurryBy/lanzou-directlink)|蓝奏云分享链接直链获取|16|2022-08-02|2022-07-26|
|11|[houxinlin/one-blog](https://github.com/houxinlin/one-blog)|单页博客:http://www.houxinlin.com|10|2022-07-29|2021-10-20|
|12|[choyy/Timeline-SY](https://github.com/choyy/Timeline-SY)|思源笔记时间线挂件|9|2022-07-05|2022-05-23|
|13|[JimHans/uestc-uestx](https://github.com/JimHans/uestc-uestx)|The polymerization of all frequently-used UESTC online services.   电子科技大学 线上服务集合索引|9|2022-04-08|2022-01-17|
|14|[UserZYF/Chrome-A4](https://github.com/UserZYF/Chrome-A4)|思源笔记的一个主题，chrome标签样式+A4纸张大小|8|2022-05-10|2022-04-10|
|15|[UserZYF/blue-dog](https://github.com/UserZYF/blue-dog)|思源笔记的主题，蓝色|5|2022-05-29|2022-04-17|
|16|[DoggyYao/css-html-demo](https://github.com/DoggyYao/css-html-demo)|css+html案例分享。对外公开，供大家下载。|4|2022-07-31|2022-05-16|
|17|[QJvic/blog.gis1024.com](https://github.com/QJvic/blog.gis1024.com)|sample code of blog.gis1024.com   --------   gis1024.com博客屋的示例代码仓库|4|2022-05-14|2022-04-27|
|18|[UserZYF/zhang-dark](https://github.com/UserZYF/zhang-dark)|一款思源笔记的夜间主题|4|2022-05-25|2022-03-11|
|19|[limboy/bytetalk.fm](https://github.com/limboy/bytetalk.fm)|聊聊程序员的那些事|4|2022-05-30|2021-10-26|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
