<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Rust
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[skyzh/type-exercise-in-rust](https://github.com/skyzh/type-exercise-in-rust)|Learn Rust black magics by implementing an expression framework in database systems|873|2022-04-12|2022-01-20|
|2|[tyrchen/geektime-rust](https://github.com/tyrchen/geektime-rust)|我的极客时间 Rust 课程的代码仓库，随课程更新|616|2022-04-28|2021-08-17|
|3|[phodal/quake](https://github.com/phodal/quake)|Quake is a knowledge management meta-framework for geeks. Use meta-data + Transflow to CRUD data,  Git + markdown to management content, Web Component for frontend-custom. Quake 是面向极客的知识管理元框架。|353|2022-07-12|2021-11-17|
|4|[wangzhe3224/awesome-systematic-trading](https://github.com/wangzhe3224/awesome-systematic-trading)|A curated list of insanely awesome libraries, packages and resources for systematic trading. Crypto, Stock, Futures, Options, CFDs, FX, and more   量化交易   量化投资|223|2022-07-31|2021-12-11|
|5|[rustlang-cn/rust-algos](https://github.com/rustlang-cn/rust-algos)|<<Rust算法题解>>，用Rust语言实现常见的算法和数据结构，以及leetcode题解，algos = algorithms，written with ❤️ by course.rs team|221|2022-07-05|2021-12-02|
|6|[sunface/fancy-rust](https://github.com/sunface/fancy-rust)|Rust酷库推荐 - 使用我们精心挑选的开源代码，让你的Rust项目Fancy起来!    Written with ❤️ by course.rs team|161|2022-02-18|2021-12-29|
|7|[doodlewind/learn-wgpu-cn](https://github.com/doodlewind/learn-wgpu-cn)|🇨🇳 《Learn Wgpu》中文版|70|2022-04-30|2022-04-23|
|8|[Justin02180218/blockchain_rust](https://github.com/Justin02180218/blockchain_rust)|本系列是用Rust实现简单的区块链，包括区块和区块链，工作量证明，交易和UTXO集合，持久化，钱包及用rust-libp2p实现的点对点分布式网络。|27|2022-04-24|2022-04-19|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
