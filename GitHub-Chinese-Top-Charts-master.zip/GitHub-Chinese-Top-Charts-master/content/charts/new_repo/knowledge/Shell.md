<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > Shell
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[Cats-Team/AdRules](https://github.com/Cats-Team/AdRules)|List of ad filters based on Chinese locale. 基于中文区的广告规则|783|2022-08-02|2021-08-06|
|2|[haixiangyan/jest-tutorial](https://github.com/haixiangyan/jest-tutorial)|🃏《Jest 实践指南》|566|2022-07-08|2022-04-24|
|3|[rootsongjc/kubernetes-hardening-guidance](https://github.com/rootsongjc/kubernetes-hardening-guidance)|《Kubernetes 加固手册》（美国国家安全局出品）- https://jimmysong.io/kubernetes-hardening-guidance|460|2022-03-13|2021-08-08|
|4|[bestxtools/awesome-toolbox-chinese](https://github.com/bestxtools/awesome-toolbox-chinese)|🧰 优秀工具箱集合 - 收集，推荐好用、优秀的工具箱。工具箱大全。|387|2022-07-27|2022-03-04|
|5|[Petit-Abba/backup_script_zh-CN](https://github.com/Petit-Abba/backup_script_zh-CN)|数据备份脚本 简体中文版|339|2022-05-15|2021-09-08|
|6|[AlphabugX/csOnvps](https://github.com/AlphabugX/csOnvps)|CobaltStrike4.4 一键部署脚本 随机生成密码、key、端口号、证书等，解决cs4.x无法运行在Linux上报错问题 灰常银杏化设计|234|2022-03-19|2021-12-02|
|7|[overmind1980/oeasypython](https://github.com/overmind1980/oeasypython)|面向初学者的简明易懂的 Python3 课程，对没有编程经验的同学也非常友好。在vim下从浅入深，逐步学习。|218|2022-05-11|2021-08-04|
|8|[rootsongjc/opentelemetry-obervability](https://github.com/rootsongjc/opentelemetry-obervability)|《OpenTelemetry 可观测性的未来》  O'Reilly 报告 |118|2022-05-19|2022-02-05|
|9|[Misaka-blog/acme-1key](https://github.com/Misaka-blog/acme-1key)|Acme.sh 域名证书一键申请脚本|102|2022-05-01|2021-12-31|
|10|[binghe001/BingheGuide](https://github.com/binghe001/BingheGuide)|📚 本代码库是作者冰河多年从事互联网大厂开发、架构的学习历程技术汇总，旨在为大家提供一个清晰详细的学习教程，侧重点更倾向编写Java核心内容、底层原理、架构知识、渗透技术。如果本仓库能为您提供帮助，请给予支持(关注、点赞、分享)！|94|2022-07-25|2022-03-31|
|11|[rootsongjc/envoy-handbook](https://github.com/rootsongjc/envoy-handbook)|Envoy 基础教程 - https://jimmysong.io/envoy-handbook/|61|2022-05-02|2022-03-01|
|12|[rootsongjc/developer-advocacy-handbook](https://github.com/rootsongjc/developer-advocacy-handbook)|开发者布道手册 - https://jimmysong.io/developer-advocacy-handbook/|33|2022-03-25|2022-03-15|
|13|[tomstillcoding/tomstillcoding.github.io](https://github.com/tomstillcoding/tomstillcoding.github.io)|🎙️这是一个通过 jekyll + GitHub Pages 搭建的个人免费博客，可以通过 fork + 改造 + 用 Typora 编写文章的方法，打造你的个人博客。特点是方便、快捷，从搭建到发布第一篇文章、访问，3分钟内解决，甚至不用写任何一行代码，博客网页内容完全自定义、无广告、无注册，各种插件免费安装！|29|2022-05-01|2022-03-26|
|14|[easyhappy/travel-coding](https://github.com/easyhappy/travel-coding)|公众号: 漫步coding, 一个分享数据库、算法、架构一些心得的公众号|28|2022-07-10|2022-03-20|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
