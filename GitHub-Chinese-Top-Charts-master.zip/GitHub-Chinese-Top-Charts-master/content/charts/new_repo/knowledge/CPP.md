<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 资料类 > C++
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[parallel101/course](https://github.com/parallel101/course)|高性能并行编程与优化 - 课件|1813|2022-07-31|2021-12-10|
|2|[yuesong-feng/30dayMakeCppServer](https://github.com/yuesong-feng/30dayMakeCppServer)|30天自制C++服务器，包含教程和源代码|778|2022-07-14|2021-11-30|
|3|[midisec/BypassAnti-Virus](https://github.com/midisec/BypassAnti-Virus)|免杀姿势学习、记录、复现。|601|2022-07-10|2022-02-18|
|4|[kahowang/sensor-fusion-for-localization-and-mapping](https://github.com/kahowang/sensor-fusion-for-localization-and-mapping)|深蓝学院 多传感器定位融合第四期 学习笔记|248|2022-05-20|2021-08-15|
|5|[shouxieai/learning-cuda-trt](https://github.com/shouxieai/learning-cuda-trt)|A large number of cuda/tensorrt cases . 大量案例来学习cuda/tensorrt|82|2022-07-24|2022-07-24|
|6|[hunterzju/llvm-tutorial](https://github.com/hunterzju/llvm-tutorial)|llvm-tutorial文档，翻译以及代码仓库|56|2022-02-20|2021-11-01|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
