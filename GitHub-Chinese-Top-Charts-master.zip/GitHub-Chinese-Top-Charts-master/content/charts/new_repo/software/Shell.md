<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > Shell
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[emptysuns/Hi_Hysteria](https://github.com/emptysuns/Hi_Hysteria)|Hello World！非钟国优化线路使用不佳？不想中转？hysteria一键搞定。|941|2022-07-07|2021-09-19|
|2|[ophub/amlogic-s9xxx-armbian](https://github.com/ophub/amlogic-s9xxx-armbian)|Armbian for Amlogic s9xxx tv box. Support a311d, s922x, s905x3, s905x2, s912, s905d, s905x, s905w, s905, etc.  including install to EMMC and update related functions. |881|2022-07-30|2021-09-19|
|3|[521xueweihan/OneFile](https://github.com/521xueweihan/OneFile)|只有一个文件！|785|2022-07-12|2022-02-21|
|4|[FlechazoPh/QLDependency](https://github.com/FlechazoPh/QLDependency)|青龙面板全依赖一键安装脚本 / Qinglong Pannel Dependency Install Scripts.|760|2022-07-28|2021-11-17|
|5|[tossp/redpill-tool-chain](https://github.com/tossp/redpill-tool-chain)|这是一个测试项目，可能会有不可预测的事情发生（比如：毁损数据、烧毁硬件等等），请谨慎使用。|603|2022-07-27|2021-08-09|
|6|[kkkyg/CFwarp](https://github.com/kkkyg/CFwarp)|Cloudflare WARP 多功能一键脚本，（自动识别WGCF与SOCKS5环境，同步循环Endpoint的IP，1：自定义设置刷新奈飞IP、自定义设置奈飞的IP区域，2：自定义设置仅刷IP区域，3：自定义WARP的IP段），支持升级WARP+及Teams账户。已测试：hax纯v6站，Euserv(德鸡)，oracle（甲骨文云）等…………功能更新增加中…|595|2022-05-13|2021-09-09|
|7|[Misaka-blog/MisakaLinuxToolbox](https://github.com/Misaka-blog/MisakaLinuxToolbox)|御坂妹妹们的Linux VPS工具箱|417|2022-05-10|2021-12-25|
|8|[liuran001/GJZS](https://github.com/liuran001/GJZS)|搞机助手·R（原「搞机助手重制版」）|401|2022-07-28|2021-08-23|
|9|[ethminerproxy/MinerProxy](https://github.com/ethminerproxy/MinerProxy)|本程序为正版原创，最稳定的ETH以太坊代理中转矿池程序，全新界面，支持ETH，ETC，抽水稳定不掉线，作者抽水千分之三，MinerProxy/矿池代理，支持TCP和SSL协议，支持自定义抽水，高性能高并发，支持web界面管理，包含自启动和进程守护，重启后可以自动运行，会放开防火墙和连接数限制，一键搞定。|292|2022-07-03|2022-01-06|
|10|[wenet-e2e/WenetSpeech](https://github.com/wenet-e2e/WenetSpeech)|A 10000+ hours dataset for Chinese speech recognition|281|2022-02-15|2021-08-03|
|11|[Misaka-blog/Xray-script](https://github.com/Misaka-blog/Xray-script)|Xray一键安装脚本，基于网络跳跃原脚本魔改，支持节点自动生成Nginx伪装站，支持和宝塔面板共存，支持IPv4、IPv6 VPS|266|2022-05-10|2022-02-14|
|12|[cxf-boluo/magisk_All](https://github.com/cxf-boluo/magisk_All)|magisk 一键集成环境，再也不用每次刷完机繁琐的配置环境了！|212|2022-07-21|2022-07-02|
|13|[DHDAXCW/OpenWRT_x86_x64](https://github.com/DHDAXCW/OpenWRT_x86_x64)|基于 Lean&Lienol 源码的 x86 的 OpenWrt 固件。|207|2022-07-29|2021-10-23|
|14|[KMinerProxy/KMinerProxy](https://github.com/KMinerProxy/KMinerProxy)|新一代轻量、多端管理的ETH抽水代理|202|2022-02-09|2022-01-31|
|15|[fscarmen/warp_unlock](https://github.com/fscarmen/warp_unlock)|WARP unlock stream media one-click script. Support IPv4, IPv6 or dual-stack CloudFlare WARP network interface and Socks5 proxy . WARP 解锁流媒体一键脚本|194|2022-07-07|2022-01-26|
|16|[r1is/CVE-2022-0847](https://github.com/r1is/CVE-2022-0847)|CVE-2022-0847-DirtyPipe-Exploit   CVE-2022-0847 是存在于 Linux内核 5.8 及之后版本中的本地提权漏洞。攻击者通过利用此漏洞，可覆盖重写任意可读文件中的数据，从而可将普通权限的用户提升到特权 root。    CVE-2022-0847 的漏洞原理类似于 CVE-2016-5195 脏牛漏洞（Dirty Cow），但它更容易被利用。漏洞作者将此 ...|187|2022-03-09|2022-03-07|
|17|[teamssix/container-escape-check](https://github.com/teamssix/container-escape-check)|docker container escape check    Docker 容器逃逸检测|183|2022-04-19|2022-03-17|
|18|[Char1es0rz/minerProxy](https://github.com/Char1es0rz/minerProxy)|以太坊矿池代理,可以自定义抽水地址和比例 ,支持热修改抽水比例。go语言编写,性能极高,唯一正版,明码标价开发费,拒绝暗抽!!!!!!|183|2022-05-19|2022-01-03|
|19|[minlearn/onekeydevdesk](https://github.com/minlearn/onekeydevdesk)|省事一键DD云虚拟机云桌面云盘伴侣🚀🚀🎉🎉|164|2022-05-11|2021-11-22|
|20|[nivin-studio/gonivinck](https://github.com/nivin-studio/gonivinck)|一个基于docker的go-zero运行环境。|155|2022-06-26|2021-12-28|
|21|[DHDAXCW/NanoPi-R2S-rk3328](https://github.com/DHDAXCW/NanoPi-R2S-rk3328)|基于 Lean&Lienol 源码的 NanoPi R2S 的 OpenWrt 固件。|151|2022-07-23|2022-05-26|
|22|[bigbugcc/OpenWrts](https://github.com/bigbugcc/OpenWrts)|OPENWRT 固件(Raspberry Pi4B/3B+，NanoPi R2S/R4S，Orange Pi R1Plus，x86) 依源码更新自动编译(周更)|151|2022-08-01|2021-10-18|
|23|[mingmingge891/FXMinerProxy](https://github.com/mingmingge891/FXMinerProxy)|全网最稳定的POW矿池转发代理工具，纯原创非破解，稳定更新，独家伪装低延迟、独家伪装提交算力、独家PID抽水算法、独家前置代理中转模式、自定义开发者抽水、自定义多钱包抽水、GoLang高性能多线程、SSL、TLS、批量中转、配置热修改、API支持，UI源码开发|124|2022-08-01|2022-01-01|
|24|[msojocs/wechat-web-devtools-linux](https://github.com/msojocs/wechat-web-devtools-linux)|微信开发者工具 纯Linux版 微信小程序|121|2022-05-14|2022-01-22|
|25|[6r6/maicai.ddxq.tools](https://github.com/6r6/maicai.ddxq.tools)|叮咚买菜相关工具|119|2022-04-09|2022-04-04|
|26|[christianhaitian/PortMaster](https://github.com/christianhaitian/PortMaster)|A simple tool that allows you to download various game ports that are available for 351Elec, ArkOS, JelOS, RetroOZ, and TheRA for RK3326 based devices and the RG552.. |118|2022-07-22|2021-09-10|
|27|[ffffffff0x/403-fuzz](https://github.com/ffffffff0x/403-fuzz)|针对 403 页面的 fuzz 脚本|110|2022-02-14|2022-02-14|
|28|[loaden/nspawn-qq](https://github.com/loaden/nspawn-qq)|利用systemd-nspawn容器跑Deepin 20.5或者Debian 11，安装deepinwine，稳定运行QQ、微信、深度商店等应用。低内存，高性能，沙盒机制不污染宿主机，支持多用户，可在所有systemd作为init的Linux发行版上运行。|108|2022-05-07|2021-09-23|
|29|[Misaka-blog/XrayR-script](https://github.com/Misaka-blog/XrayR-script)|XrayR一键安装脚本|105|2022-05-10|2022-04-27|
|30|[crazypeace/V2ray_VLESS_WebSocket_TLS_CaddyV2](https://github.com/crazypeace/V2ray_VLESS_WebSocket_TLS_CaddyV2)|V2ray最新版本，VLESS_WebSocket_TLS模式，CaddyV2前置解除TLS和path|93|2022-07-27|2022-02-27|
|31|[zhenxun-org/zhenxun_bot-deploy](https://github.com/zhenxun-org/zhenxun_bot-deploy)|真寻bot一键部署脚本|91|2022-07-06|2022-03-31|
|32|[HT944/MadRabbit](https://github.com/HT944/MadRabbit)|Rabbit新登陆方式|91|2022-07-28|2022-02-10|
|33|[DHDAXCW/NanoPi-R2C-Plus](https://github.com/DHDAXCW/NanoPi-R2C-Plus)|基于lean和immortalwrt编译第三方固件，每天自动更新插件和内核，Fusion编译法|91|2022-06-16|2021-08-09|
|34|[wy580477/Heroku-All-In-One-APP](https://github.com/wy580477/Heroku-All-In-One-APP)|yt-dlp+Aria2+WebUI+Rclone auto-upload+Filebrowser+Xray Vmess proxy& more on Heroku   Heroku 全能 APP|84|2022-05-21|2022-04-13|
|35|[yaya131/X86_64-TEST](https://github.com/yaya131/X86_64-TEST)|自动构建openwrt官方源码！集成usb网卡，支持安卓手机usb网络共享，pci网卡暂时还没有集成，集成了20个插件，分为docker版，和精简版。docker分区1024。精简版分区300，diy2是添加lede软件库没有的插件。及一些原作者的插件。lite精简版配置config和docker版配置基本上都有简单说明。|83|2022-08-02|2021-09-17|
|36|[pmkol/easymosdns](https://github.com/pmkol/easymosdns)|简化Mosdns基本功能使用的辅助脚本，仅需几分钟即可搭建一台支持ECS的无污染DNS服务器|82|2022-08-02|2022-07-01|
|37|[flyqie/dd-shell](https://github.com/flyqie/dd-shell)|该脚本可在DD系统时为您提供一个WebUI以帮助您了解到目前的DD状态.|82|2022-05-29|2021-11-21|
|38|[hugcabbage/shared-lede](https://github.com/hugcabbage/shared-lede)|定制编译OpenWrt固件|80|2022-07-05|2022-03-06|
|39|[King-stark/NvJDCloud](https://github.com/King-stark/NvJDCloud)|Nolanjdc 诺兰面板安装说明|80|2022-03-25|2021-11-28|
|40|[haiibo/OpenWrt](https://github.com/haiibo/OpenWrt)|多设备 OpenWrt 固件云编译——X86、R2S、R4S、微加云、贝壳云、我家云、N1、章鱼星球、S905x2、S905x3（包括常见的HK1、H96、X96等盒子）、S922x（GT-King、GT-King Pro、Odroid N2）|76|2022-07-02|2021-10-10|
|41|[DaoCloud/public-image-mirror](https://github.com/DaoCloud/public-image-mirror)|很多镜像都在国外。比如 gcr 。国内下载很慢，需要加速。|73|2022-05-15|2021-09-09|
|42|[wy580477/Leech-AIO-APP-EX](https://github.com/wy580477/Leech-AIO-APP-EX)|All Downloaders with Rclone auto-upload & more on Docker/Colab/Heroku   Docker/Colab/Heroku 全能下载 APP|69|2022-07-25|2022-05-21|
|43|[yaya131/OpenWrt_R7800_Stable](https://github.com/yaya131/OpenWrt_R7800_Stable)|跟随LEDE主线更新。极致AP版和精简版，更新频率：跟随源码更新而更新，涵盖机型R7800 ---XR500 ---K2P---新三---E8450----AX6S-5.15  |69|2022-08-01|2021-08-10|
|44|[Misaka-blog/argo-tunnel-script](https://github.com/Misaka-blog/argo-tunnel-script)|CloudFlare Argo Tunnel 1key script|60|2022-05-01|2022-02-11|
|45|[FuckMiner/FuckProxy](https://github.com/FuckMiner/FuckProxy)|最新ETH/ETC矿池代理中转程序FuckProxy,Web界面操作，简单易用，一键安装，小白可以轻松上手。 采用Golang语言开发，性能稳定优异。 无视CC，自动CC防护，自动封IP。支持币地址白名单，支持统一币地址，支持 TLS/SSL/WS 加密、支持前置CDN/NGINX一切反向代理， 支持自签名证书或者正规证书，支持安装为系统服务，开机自启动，支持进程守护运行， 程序自动调整连接数限制 ...|58|2022-03-26|2022-03-18|
|46|[YidaozhanYa/RyujinxCN](https://github.com/YidaozhanYa/RyujinxCN)|Ryujinx 简体中文汉化补丁及自动构建|56|2022-05-16|2022-02-05|
|47|[EdNovas/vpstoolbox](https://github.com/EdNovas/vpstoolbox)|EdNovas的VPS工具箱|55|2022-07-22|2021-12-27|
|48|[lxgw/advanced-cjk-font-magisk-module-template](https://github.com/lxgw/advanced-cjk-font-magisk-module-template)|A Magisk module template to systemlessly replace system fonts. Supports CJK Fonts. 用于制作字体模块的 Magisk 模块模板，支持中日韩字体的替换。|54|2022-06-06|2021-11-10|
|49|[SinKy-Yan/zhenxunbot-docker](https://github.com/SinKy-Yan/zhenxunbot-docker)|真寻BOT的Docker镜像编译源码，已集成运行BOT必须的PostgreSQL、绪山真寻BOT|51|2022-07-24|2022-05-24|
|50|[spiritLHLS/Hang-up-items](https://github.com/spiritLHLS/Hang-up-items)|问卷调查项目，云服务器推荐，挂机项目，各种脚本收集。欢迎右上角点铃铛及时收取更新信息。(不要fork，低调) |51|2022-07-23|2022-04-11|
|51|[FrankFang/oh-my-docker](https://github.com/FrankFang/oh-my-docker)|-|50|2022-08-02|2021-08-25|
|52|[wy580477/PaaS-vmess-trojan-argo](https://github.com/wy580477/PaaS-vmess-trojan-argo)|在 Heroku 以及其它 PaaS 平台上部署 Vmess WebSocket 和 Trojan Websocket 协议，支持WS-0RTT降低延迟，并可开启 Cloudflare Argo 隧道。|48|2022-07-12|2022-03-17|
|53|[lxgw/simple-cjk-font-magisk-module-template](https://github.com/lxgw/simple-cjk-font-magisk-module-template)|A Magisk module template to systemlessly replace system fonts. Supports CJK Fonts. 用于制作字体模块的 Magisk 模块模板，支持中日韩字体的替换。|48|2022-06-06|2021-10-28|
|54|[kenzok8/compile-package](https://github.com/kenzok8/compile-package)|small-package仓库，每日更新插件编译|46|2022-08-02|2021-09-29|
|55|[BingMeme/OpenWrt_CN](https://github.com/BingMeme/OpenWrt_CN)|OpenWrt_简中|45|2022-05-08|2022-03-29|
|56|[Misaka-blog/Misaka-WARP-Script](https://github.com/Misaka-blog/Misaka-WARP-Script)|Misaka WARP 脚本、支持手工菜单+全自动化脚本安装。支持AMD64、ARM64和S390X CPU架构的VPS、支持KVM、ZVM、OpenVZ和LXC虚拟化架构的VPS|45|2022-05-13|2022-03-18|
|57|[kenzok78/Bulid_Wrt](https://github.com/kenzok78/Bulid_Wrt)|openwrt官方源码纯净编译|44|2022-06-01|2021-09-05|
|58|[entr0pia/trichromelibrary-squoosh](https://github.com/entr0pia/trichromelibrary-squoosh)|Remove the outdated TrichromeLibrary   移除过时的 TrichromeLibrary |41|2022-06-23|2021-12-09|
|59|[sudongyuer/react-patterns](https://github.com/sudongyuer/react-patterns)|☄️ React相关der设计模式|40|2022-05-30|2022-02-05|
|60|[Left024/BiliFavoritesDownloader](https://github.com/Left024/BiliFavoritesDownloader)|自动下载B站收藏视频，支持自动下载封面图，自动转换xml至ass，下载完成自动上传 OneDrive，邮件通知，telegram 通知（实时下载进度查看）|39|2022-04-18|2021-09-13|
|61|[yhan219/navicat_reset_mac](https://github.com/yhan219/navicat_reset_mac)|navicat16 mac版无限重置试用期脚本|38|2022-05-26|2022-02-25|
|62|[kkkyg/vpsroot](https://github.com/kkkyg/vpsroot)|一键获取最高root权限，自定义root密码！支持Euserv德鸡，Hax IPV6，甲骨文oracle、谷歌云gpc、IBM Linux one、亚马逊云azurz等VPS|38|2022-02-22|2021-09-09|
|63|[DHDAXCW/DoorNet_Series](https://github.com/DHDAXCW/DoorNet_Series)|基于 Lean&Lienol 源码的 DoorNet1 的 OpenWrt 固件。|35|2022-07-23|2021-08-14|
|64|[Misaka-blog/Hysteria-script](https://github.com/Misaka-blog/Hysteria-script)|Hysteria 一键脚本，支持IPv4、IPv6 VPS|32|2022-05-12|2022-05-07|
|65|[minerhome/mh_tunnel](https://github.com/minerhome/mh_tunnel)|加密隧道流量混淆|32|2022-07-30|2022-02-10|
|66|[spiritLHLS/ecs](https://github.com/spiritLHLS/ecs)|融合怪测评脚本(测评频道：https://t.me/vps_reviews )(脚本未完善，点star就好了，fork属实没啥必要)|31|2022-08-02|2022-06-09|
|67|[iwhalecloud-platform/redis-tool](https://github.com/iwhalecloud-platform/redis-tool)|Redis Cluster Daily Maintenance Tool/Redis集群日常运维工具|31|2022-07-22|2022-04-29|
|68|[huzesama/ASGuard](https://github.com/huzesama/ASGuard)|Magisk模块，用于安卓的无障碍服务(或名:辅助功能)辅助管理模块|30|2022-05-07|2022-04-19|
|69|[guo-yong-zhi/kindle-filebrowser](https://github.com/guo-yong-zhi/kindle-filebrowser)|在网页管理Kindle的文件|30|2022-07-24|2021-08-27|
|70|[zhangguanzhang/Actions-OpenWrt](https://github.com/zhangguanzhang/Actions-OpenWrt)|x86_64/r2s/r4s/树莓派4/doornet2/r1s-h5 openwrt 多源码固件在线编译|30|2022-08-02|2021-08-14|
|71|[tick-guo/openwrt-rom](https://github.com/tick-guo/openwrt-rom)|自动打包openwrt image, 仅含 x86, x64, K2(a), K2P(a). 4种型号.|28|2022-08-01|2021-10-11|
|72|[tax0x7e7/tax_miner_proxy](https://github.com/tax0x7e7/tax_miner_proxy)|中转服务器挖矿抽水脚本，支持跨矿池抽水|26|2022-05-07|2021-12-27|
|73|[spiritLHLS/lxc](https://github.com/spiritLHLS/lxc)|母鸡开小鸡，一键多开小鸡，一键多开NAT小鸡，一键LXC虚拟化，一键多开服务器，多开容器，一键多开NAT小鸡，一键多开NAT服务器。(初始化只需几分钟，开小鸡等待时长和数量有关)(免费服务器)|25|2022-07-23|2022-05-04|
|74|[suminerProxy/suminerProxy](https://github.com/suminerProxy/suminerProxy)|SuMinerProxy是目前市面上最稳定、价格最低(目前固定开发者费用为0%)、功能最全的矿池代理。全面支持专业矿机。支持CC、DDOS防御！！！支持内置抽水！！！支持一键在windows和Linux系统上搭建矿池抽水代理，使用ssl/tcp转发加密传输数据，支持一键屏蔽服务商的监管系统，使你的行为更加安全私密，防止服务器ip被查封。 可拓展匿名代理，保护服务器，防止DDOS攻击，让你的用户更加 ...|25|2022-02-24|2022-01-04|
|75|[Miuzarte/hijk.sh](https://github.com/Miuzarte/hijk.sh)|v2raytech.com脚本(不全)备份整理, 附带个人自用修复root检测|24|2022-03-31|2021-09-19|
|76|[DHDAXCW/DoorNet2](https://github.com/DHDAXCW/DoorNet2)|基于 Lean&Lienol 源码的 DoorNet2 的 OpenWrt 固件。|23|2022-07-23|2021-10-28|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
