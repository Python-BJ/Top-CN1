<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > HTML
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[sunym1993/flash-linux0.11-talk](https://github.com/sunym1993/flash-linux0.11-talk)|你管这破玩意叫操作系统源码 — 像小说一样品读 Linux 0.11 核心代码|13304|2022-07-22|2021-11-06|
|2|[Alpha-Yang/CS-BAOYAN-2022](https://github.com/Alpha-Yang/CS-BAOYAN-2022)|计算机保研交流群（QQ群号：605176069）|810|2022-04-07|2021-10-16|
|3|[momo0853/kkndme](https://github.com/momo0853/kkndme)|kkndme聊房，数据整理自天涯。提供HTML、PDF和Markdown三种形式。|674|2022-06-13|2021-09-10|
|4|[Threekiii/Vulnerability-Wiki](https://github.com/Threekiii/Vulnerability-Wiki)|一个综合漏洞知识库，集成了Vulhub、Peiqi、Edge、0sec、Wooyun等开源漏洞库|331|2022-07-22|2022-04-29|
|5|[sfvsfv/ComputerStudent](https://github.com/sfvsfv/ComputerStudent)|计算机专业系统性学习资料（python,c,c++,计算机组成，计算机网络，编译原理，电路，谷歌插件，爬虫）|323|2022-05-12|2022-04-02|
|6|[ccminerproxy/CC-MinerProxy](https://github.com/ccminerproxy/CC-MinerProxy)|ETH,BTC,ETC中转抽水,有效防止CC攻击。支持SSL加密，后台web页监控，实时查看自己抽水情况。|224|2022-05-30|2022-01-15|
|7|[xianyukang/MyKeymap](https://github.com/xianyukang/MyKeymap)|MyKeymap: 我的按键映射工具|192|2022-05-11|2021-10-18|
|8|[xiaolai/apple-computer-literacy](https://github.com/xiaolai/apple-computer-literacy)|个人电脑使用（以苹果产品为例）|177|2022-05-10|2021-10-02|
|9|[smxl/500](https://github.com/smxl/500)|精简 GeoIP for Quantumult X / Clash 预配置文件: Apple News 解锁规则 + 捷径, 去广告分流规则, TikTok 解锁 Rewrite, 神机分流规则, VIP 视频解析重写 + 捷径|170|2022-03-01|2021-11-18|
|10|[A-Soul-Database/A-Soul-Database](https://github.com/A-Soul-Database/A-Soul-Database)|A-Soul db A-Soul第三方直播数据|170|2022-04-03|2021-08-06|
|11|[DaoChen6/Heroku-v2ray](https://github.com/DaoChen6/Heroku-v2ray)|在Heroku上部署v2ray|167|2022-05-11|2021-08-24|
|12|[code-scan/LoginFish](https://github.com/code-scan/LoginFish)|通用登录页面安全控件钓鱼|155|2022-06-30|2022-06-28|
|13|[evmn/Paul-Graham](https://github.com/evmn/Paul-Graham)|Paul Graham's Essays, Kindle version, set several sections for easy navigation|152|2022-02-26|2021-10-29|
|14|[plazum/find-keke](https://github.com/plazum/find-keke)|寻找唐可可|128|2022-03-13|2021-11-23|
|15|[PanDownload-Fix/PanDownload-Fix](https://github.com/PanDownload-Fix/PanDownload-Fix)|PanDownload 修复版|127|2022-04-18|2021-09-03|
|16|[3293172751/Block_Chain](https://github.com/3293172751/Block_Chain)|Block_Chain是区块链开发笔记和项目代码，包含区块链路线，Go语言学习路线，Go语言笔记，Go语言开发后端路线，密码学原理，fabric，hyperledger，docker容器技术，git，nginx，区块链原理，基本框架，IPFS技术，pbft共识算法，Go语言开发的项目，区块链的开发项目，redis技术（三主三重和主从扩容）和分布式算法，加密货币开发流程，将其上传到GitHub，如果 ...|125|2022-08-02|2022-01-04|
|17|[SexyBeast233/SecBooks](https://github.com/SexyBeast233/SecBooks)|安全类各家文库大乱斗|110|2022-02-15|2022-02-15|
|18|[L-M-Sherlock/sm18-lazy-package](https://github.com/L-M-Sherlock/sm18-lazy-package)|SuperMemo 18 中文懒人包|97|2022-06-19|2021-11-06|
|19|[yiqia/student_system](https://github.com/yiqia/student_system)|基于thinkphp6.0+mysql+bootstrap4的疫情防控系统毕业设计|93|2022-03-14|2021-12-04|
|20|[Denkiame/Tategaki](https://github.com/Denkiame/Tategaki)|Translate Telegra.ph to vertical writing.|84|2022-04-06|2021-08-27|
|21|[liu673cn/biubiu](https://github.com/liu673cn/biubiu)|biubiu播放器|76|2022-06-23|2022-05-10|
|22|[firemakergk/aquar-home](https://github.com/firemakergk/aquar-home)|-|76|2022-03-23|2021-11-19|
|23|[Oreomeow/freenom-py](https://github.com/Oreomeow/freenom-py)|Freenom 域名自动续约 python 项目|75|2022-07-20|2021-08-21|
|24|[erdengk/gsoc-analyse](https://github.com/erdengk/gsoc-analyse)|帮助新手参与开源|69|2022-05-12|2022-01-10|
|25|[tansuotv/tansuotv](https://github.com/tansuotv/tansuotv)|探索TV 发现更美 t.tansuo.tv|66|2022-07-26|2021-11-29|
|26|[kingcata/zhxx](https://github.com/kingcata/zhxx)|学习强国自动刷分，学习强国自动学习，学习强国自动答题，挑战答题题库。软件适用于Win7以上系统，绿色软件，解压后直接运行，无需安装配置python环境。⭐⭐⭐8分钟学完45分！⭐⭐⭐|60|2022-05-12|2021-10-26|
|27|[qwd/Icons](https://github.com/qwd/Icons)|和风天气开源图标字体库 Open source weather icons && fonts for QWeather|58|2022-02-25|2021-09-23|
|28|[midorg-com/midorg](https://github.com/midorg-com/midorg)|元岛社区的代码仓库|57|2022-07-27|2022-06-04|
|29|[itorr/magi](https://github.com/itorr/magi)|👩🏼 「MAGI System」一键决议系统|53|2022-07-16|2022-06-08|
|30|[zhanglele666/loli3_RC](https://github.com/zhanglele666/loli3_RC)|追梦版本的萝丽三代遥控器项目|53|2022-03-31|2022-03-19|
|31|[xiaoyou-bilibili/xblog](https://github.com/xiaoyou-bilibili/xblog)|xblog博客系统|49|2022-05-25|2022-05-03|
|32|[DistSysCorp/ddia](https://github.com/DistSysCorp/ddia)|DDIA 逐章精读|49|2022-07-19|2022-02-16|
|33|[WeixinCloud/wxcloudrun-springboot](https://github.com/WeixinCloud/wxcloudrun-springboot)|微信云托管 springboot 框架模版|46|2022-07-07|2021-09-22|
|34|[ZhongFuCheng3y/austin-admin](https://github.com/ZhongFuCheng3y/austin-admin)|austin项目前端，依赖amis|45|2022-06-28|2022-01-22|
|35|[AndyXFuture/MCar-Arduino-ESP01S](https://github.com/AndyXFuture/MCar-Arduino-ESP01S)|A Mecanum-wheel car based on ESP01S.|45|2022-04-16|2021-11-02|
|36|[lewangdev/shanghai-lockdown-covid-19](https://github.com/lewangdev/shanghai-lockdown-covid-19)|Coronavirus (COVID-19) statistics data in Shanghai lockdown. 封控期间上海疫情数据，包括病例数、死亡数、确诊数、无症状数和疫情地址等。|43|2022-06-06|2022-04-16|
|37|[malaohu/GitHubHosts](https://github.com/malaohu/GitHubHosts)|轻松解决国内无法访问Github的囧境|43|2022-05-26|2021-12-12|
|38|[ye-tutu/TuHome](https://github.com/ye-tutu/TuHome)|一个简洁、轻快的开源的毛玻璃风格个人主页主题|39|2022-06-04|2021-11-13|
|39|[Keywos/loon-shadowrocket](https://github.com/Keywos/loon-shadowrocket)|自用去广告规则 loon、小火箭，无分流规则|37|2022-07-25|2022-04-27|
|40|[datahu-cn/report-designer](https://github.com/datahu-cn/report-designer)|Data Hu 报表设计器, 用于数据分析、数据建模、报表设计、BI、大屏展示|36|2022-04-14|2021-09-07|
|41|[NEUQ-ACM/Experimental-Class-Weekly](https://github.com/NEUQ-ACM/Experimental-Class-Weekly)|工程创新实践实训实验班|34|2022-07-12|2021-12-29|
|42|[cym1102/svnWebUI](https://github.com/cym1102/svnWebUI)|svn服务端web图形化管理系统, 搭建svn服务器的神器.|34|2022-06-06|2021-12-15|
|43|[chiron-fonts/chiron-sung-hk](https://github.com/chiron-fonts/chiron-sung-hk)|昭源宋體：現代筆形風格，平衡標準字形和印刷體慣用筆形的免費開源宋體字型|32|2022-07-15|2021-11-21|
|44|[houdunwang/vue](https://github.com/houdunwang/vue)|VUE 前端脚手架|29|2022-07-28|2021-12-17|
|45|[aoyouer/digital-pigeon](https://github.com/aoyouer/digital-pigeon)|A digital pigeon, send tempory messages with cloudflare workers. 咕咕传信，使用cloudflare workers来发送信息。可指定访问一定次数后删除记录，可以指定密钥加密，可用来交换一些临时但敏感的信息。 demo: https://digitalpigeon.aoyou.workers.dev/ https://msg.rmrf ...|28|2022-03-21|2022-03-19|
|46|[MiuliKain/FreeNode](https://github.com/MiuliKain/FreeNode)|一个为大家提供免费的、高可用的、不断更新的节点列表的地方，不管你是需要稳定的节点，还是来这里寻找度过敏感时期的稻草，我们都随时对任何人开放|27|2022-02-26|2022-02-14|
|47|[Re1own/IoT_Sec](https://github.com/Re1own/IoT_Sec)|林中有两条路，我选择了人迹罕至的一条|27|2022-03-22|2021-11-23|
|48|[zjgsuzjx/acg](https://github.com/zjgsuzjx/acg)|🍬一个关于我的ACG收藏夹|26|2022-06-21|2021-08-03|
|49|[WeixinCloud/wxcloudrun-express](https://github.com/WeixinCloud/wxcloudrun-express)|微信云托管 express 框架模版|25|2022-06-23|2021-09-22|
|50|[bangumi/dev-docs](https://github.com/bangumi/dev-docs)|development documents / 开发文档|24|2022-07-23|2021-12-07|
|51|[aeraki-mesh/istio-operation-bible](https://github.com/aeraki-mesh/istio-operation-bible)|Istio 运维实战 https://istio-operation-bible.aeraki.net|24|2022-07-06|2021-09-24|
|52|[z1un/tools.zjun.info](https://github.com/z1un/tools.zjun.info)|一些在线的网络安全相关工具|23|2022-03-03|2022-02-28|
|53|[fengtianxi001/MF-MTools](https://github.com/fengtianxi001/MF-MTools)|前端开发工具|23|2022-05-15|2021-08-09|
|54|[uappkit/uapp-android](https://github.com/uappkit/uapp-android)|uapp android 工程模板, 使用详情看 https://github.com/uappkit/uapp|22|2022-05-16|2022-02-15|
|55|[2460392754/uniapp-router-view-loader](https://github.com/2460392754/uniapp-router-view-loader)|全网首个专属于UniApp的编译工具插件，全面支持各平台、各环境、各语言、各类型文件、各编译工具。|21|2022-04-14|2022-02-14|
|56|[rawchen/AliPan](https://github.com/rawchen/AliPan)|阿里云盘列表程序 - Spring Boot|21|2022-08-01|2021-10-27|
|57|[songquanpeng/pronunciation-corrector](https://github.com/songquanpeng/pronunciation-corrector)|拯救你的英语发音，告别因发音错误带来的尴尬！|20|2022-02-17|2022-02-16|
|58|[TW527E/renexmoe-tw527e-edition](https://github.com/TW527E/renexmoe-tw527e-edition)|高顏值 OneManager 主題，作用於 OneManager-php，提供多種CDN|19|2022-07-01|2022-04-24|
|59|[qinlili23333/545WebPlayer](https://github.com/qinlili23333/545WebPlayer)|随时随地在线补充塔能量|19|2022-07-09|2022-03-25|
|60|[orleven/Celestion](https://github.com/orleven/Celestion)|Celestion 是一个无回显漏洞测试辅助平台，平台使用flask编写，提供DNSLOG，HTTPLOG等功能。 (界面懒得弄，后续有需要再说)。|19|2022-07-14|2022-01-07|
|61|[Ukenn2112/qinglongAPI_doc](https://github.com/Ukenn2112/qinglongAPI_doc)|Qinglong API 文档|14|2022-03-01|2022-02-09|
|62|[kirov-opensource/starsharks_tools](https://github.com/kirov-opensource/starsharks_tools)|星鲨工具箱|13|2022-04-04|2022-03-31|
|63|[v2rayA/v2raya.github.io](https://github.com/v2rayA/v2raya.github.io)|[WIP]  v2rayA 项目官方文档 ，使用 Hugo / Markdown， 欢迎帮助完善 & 提交 PR！|13|2022-05-09|2021-08-20|
|64|[CorrectRoadH/logseq-plugins-develop-tutorial](https://github.com/CorrectRoadH/logseq-plugins-develop-tutorial)|这是一本关于logseq 插件开发的教程。还在写之中。|12|2022-04-30|2022-02-07|
|65|[alex3236/pay](https://github.com/alex3236/pay)|一个简单的收款码展示页——我很可爱，请给我钱（划掉）|12|2022-03-18|2021-12-04|
|66|[SABERBOY/CocosCreator3DPlayable](https://github.com/SABERBOY/CocosCreator3DPlayable)|CocosCreator3D 试玩广告(Playable)制作解决方案,现在已经适配最新版本CocosCreator3D 3.4.1|12|2022-04-01|2021-09-22|
|67|[clouDr-f2e/rubick-plugin-monalisa](https://github.com/clouDr-f2e/rubick-plugin-monalisa)|UI走查工具|12|2022-04-20|2021-08-18|
|68|[bilibilifmk/KVM](https://github.com/bilibilifmk/KVM)|开源 双/多 平台KVM切换器 |11|2022-03-28|2022-03-12|
|69|[xujimu/ios_super_sign_docker](https://github.com/xujimu/ios_super_sign_docker)|超级签名 企业签名 免签封装 app打包 应用多开 自助分发 多合一系统 支持15系统 两条命令即可安装使用|11|2022-05-06|2022-03-10|
|70|[ant-design/next-pro-components](https://github.com/ant-design/next-pro-components)|下一个版本的 pro-components|11|2022-04-08|2022-02-28|
|71|[zhizhuoshuma/cve_info_data](https://github.com/zhizhuoshuma/cve_info_data)|各大平台IOT设备漏洞资源库|11|2022-05-07|2022-02-15|
|72|[zkeq/icodeq-api](https://github.com/zkeq/icodeq-api)|自用 API 地址|11|2022-05-06|2022-02-07|
|73|[welai/secondary-axes](https://github.com/welai/secondary-axes)|第二中心线计算器|11|2022-02-13|2021-10-19|
|74|[MagmaBlock/LavaAnimeWeb](https://github.com/MagmaBlock/LavaAnimeWeb)|熔岩番剧库，一个自用的私有动画库。此仓库为静态网页托管及源码|11|2022-05-06|2021-09-22|
|75|[httIsHere/notion-widget](https://github.com/httIsHere/notion-widget)|Notion   Wolai 组件库|11|2022-04-19|2021-08-13|
|76|[gledos/ggame](https://github.com/gledos/ggame)|ggame Wiki 是一个记录整理游戏和谐的基于 mkdocs 的百科|11|2022-05-09|2021-08-09|
|77|[bytesfly/blog](https://github.com/bytesfly/blog)|互联网是有记忆的，我想留下一些成长的脚印。|10|2022-03-14|2021-09-15|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
