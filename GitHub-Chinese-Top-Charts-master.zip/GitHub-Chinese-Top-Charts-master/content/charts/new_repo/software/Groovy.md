<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > Groovy
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[DreamPWJ/jenkins-shared-library](https://github.com/DreamPWJ/jenkins-shared-library)|强大灵活易用的多端CI/CD共享库流水线 One For All DevOps |14|2022-03-29|2022-02-14|
|2|[dqzboy/DevOps](https://github.com/dqzboy/DevOps)|CICD流水线|11|2022-03-08|2021-12-02|
|3|[TabooLib/shrinking-kotlin](https://github.com/TabooLib/shrinking-kotlin)|Reduce file size after Kotlin compilation|5|2022-02-11|2022-01-27|
|4|[eonliu/packer](https://github.com/eonliu/packer)|一个Android打包工具插件，支持360加固、多渠道打包、将APK上传到FTP等功能。|3|2022-03-31|2022-01-24|
|5|[vSimpleton/UploadApkPlugin](https://github.com/vSimpleton/UploadApkPlugin)|Gradle自定义插件，一键实现打包apk、加固apk、上传到蒲公英并发送消息到钉钉群|2|2022-03-15|2022-02-25|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
