<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > JavaScript
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[babysor/MockingBird](https://github.com/babysor/MockingBird)|🚀AI拟声: 5秒内克隆您的声音并生成任意语音内容 Clone a voice in 5 seconds to generate arbitrary speech in real-time|23511|2022-07-19|2021-08-07|
|2|[VirgilClyne/iRingo](https://github.com/VirgilClyne/iRingo)|解锁完整的 Apple功能和集成服务|4372|2022-07-30|2021-10-16|
|3|[Reamd7/notion-zh_CN](https://github.com/Reamd7/notion-zh_CN)|notion 中文化|2001|2022-07-13|2021-08-12|
|4|[Le-niao/Yunzai-Bot](https://github.com/Le-niao/Yunzai-Bot)|原神QQ群机器人，通过米游社接口，查询原神游戏信息，快速生成图片返回|1418|2022-08-02|2021-11-02|
|5|[RimoChan/match-you](https://github.com/RimoChan/match-you)|【您配吗】配你吗|1322|2022-03-10|2021-11-19|
|6|[Java-S12138/frank](https://github.com/Java-S12138/frank)|一款全新的英雄联盟(LOL)助手软件.............. A bran-new League of Legends assistant software, a replacement for WeGame.|1259|2022-08-02|2022-07-04|
|7|[KingRan/KR](https://github.com/KingRan/KR)|-|1002|2022-07-31|2022-02-11|
|8|[gys619/Absinthe](https://github.com/gys619/Absinthe)|一个兴趣使然的库|1002|2022-08-02|2021-09-02|
|9|[vshymanskyy/StandWithUkraine](https://github.com/vshymanskyy/StandWithUkraine)|StandWithUkraine support materials|963|2022-07-26|2022-02-28|
|10|[AlynxZhou/gnome-shell-extension-inotch](https://github.com/AlynxZhou/gnome-shell-extension-inotch)|Add a useless notch to your screen.|948|2022-07-11|2021-10-20|
|11|[Tencent/cherry-markdown](https://github.com/Tencent/cherry-markdown)|✨ A Markdown Editor|926|2022-08-02|2021-10-15|
|12|[feeddd/feeds](https://github.com/feeddd/feeds)|免费的公众号 RSS，支持扩展任意 APP|807|2022-07-31|2021-08-17|
|13|[foamzou/melody](https://github.com/foamzou/melody)|我的音乐精灵|763|2022-07-31|2021-12-05|
|14|[tobe-fe-dalao/fast-vue3](https://github.com/tobe-fe-dalao/fast-vue3)|Vue3+Vite+Ts+Pinia+...一个快速开发vue3的模板框架|726|2022-07-28|2021-12-21|
|15|[easychen/checkchan-dist](https://github.com/easychen/checkchan-dist)|Check酱：监测网页内容变化，并发送异动到微信。亦支持http status、json和rss监测。配合自架云端，关电脑后也能运行。|673|2022-08-01|2022-05-21|
|16|[uappkit/uapp](https://github.com/uappkit/uapp)|uniapp是一个基于Vue同构技术的多平台前端框架，熟悉Vue就可以同时写App(android/ios)，H5，微信/抖音/百度/支付宝等各家小程序，维护一套代码可以发布10多个平台。uapp 是一个提升 uniapp 开发效率的脚手架工具，类似 cordova, ionic, expo 的作用。uapp还包含 uapp-android, uapp-ios 两个平台的模板代码。|659|2022-06-12|2022-02-15|
|17|[anaer/Sub](https://github.com/anaer/Sub)|自用clash订阅链接|602|2022-08-02|2021-11-04|
|18|[shenruisi/Stay](https://github.com/shenruisi/Stay)|Stay is a local userscript manager and an extension sample for Safari on iOS/iPadOS.|590|2022-07-27|2021-10-24|
|19|[Nerver4Ever/SevenSha1UIAdvancedHelper](https://github.com/Nerver4Ever/SevenSha1UIAdvancedHelper)|转存助手ui优化版|542|2022-06-16|2022-04-26|
|20|[elias-sundqvist/obsidian-annotator](https://github.com/elias-sundqvist/obsidian-annotator)|A plugin for reading and annotating PDFs and EPUBs in obsidian. |517|2022-08-02|2021-08-25|
|21|[Tsaiboss/decodeObfuscator](https://github.com/Tsaiboss/decodeObfuscator)|免安装一键还原Obfuscator混淆过的代码|498|2022-05-31|2022-04-06|
|22|[cilame/v_jstools](https://github.com/cilame/v_jstools)|模仿着写一个开源的 chrome 插件，用来快速调试前端 js 代码。|495|2022-07-30|2021-09-25|
|23|[SiJiDo/H](https://github.com/SiJiDo/H)|H是一款强大的资产收集管理平台|488|2022-05-18|2021-09-10|
|24|[chaos-zhu/easynode](https://github.com/chaos-zhu/easynode)|一个简易的个人Linux服务器管理面板【需求与bug请提交issue】|475|2022-07-01|2022-06-08|
|25|[764763903a/xdd-plus](https://github.com/764763903a/xdd-plus)|xdd-plus|475|2022-05-25|2021-09-06|
|26|[91p2022/91](https://github.com/91p2022/91)|91porn 解锁91pornVIP Authorize anyone to distribute for non-profit 授权任何人非盈利分发|469|2022-07-27|2022-04-25|
|27|[zhengjim/camille](https://github.com/zhengjim/camille)|基于Frida的Android App隐私合规检测辅助工具|465|2022-07-08|2021-10-28|
|28|[VideoTogether/VideoTogether](https://github.com/VideoTogether/VideoTogether)|Watch video together on any platform / 一起看视频，兼容所有平台|442|2022-07-30|2022-06-23|
|29|[csmsapp/csmsapp.github.io](https://github.com/csmsapp/csmsapp.github.io)|计算机硕士出国申请   CS Masters Application|432|2022-07-30|2022-03-28|
|30|[DualSubs/DualSubs](https://github.com/DualSubs/DualSubs)|流媒体平台字幕增强及双语模块|428|2022-06-30|2022-02-28|
|31|[cweijan/JD_tencent_scf](https://github.com/cweijan/JD_tencent_scf)|打京豆部署介绍|401|2022-06-01|2022-02-08|
|32|[sml2h3/ast_tools](https://github.com/sml2h3/ast_tools)|ast基础框架-基于babel|400|2022-03-11|2022-03-11|
|33|[Yiov/wool](https://github.com/Yiov/wool)|略略略略略|400|2022-07-17|2021-11-06|
|34|[zclzone/vue-naive-admin](https://github.com/zclzone/vue-naive-admin)|⚡️基于 Vue3 + Vite + Pinia + Unocss + Naive UI 的轻量级后台管理模板。|372|2022-08-02|2022-01-08|
|35|[VirgilClyne/GetSomeFries](https://github.com/VirgilClyne/GetSomeFries)|整点薯条|363|2022-05-11|2021-12-18|
|36|[b0bac/ApolloScanner](https://github.com/b0bac/ApolloScanner)|自动化巡航扫描框架（可用于红队打点评估）|353|2022-03-24|2022-03-17|
|37|[eolinker/eoapi](https://github.com/eolinker/eoapi)|Eoapi 是一个可扩展的 API 开发工具。Eoapi 集合基础的 API 管理和测试功能，并且可以通过插件简化你的 API 开发工作，让你可以更快更好地创建 API。|351|2022-08-02|2021-11-24|
|38|[tangly1024/NotionNext](https://github.com/tangly1024/NotionNext)|一个使用 NextJS + Notion API 实现的，部署在 Vercel 上的静态博客系统。为Notion和所有创作者设计。|350|2022-07-28|2021-09-26|
|39|[qishanzhiruan/basemall](https://github.com/qishanzhiruan/basemall)|🥇🥇🥇商城系统-  java商城 B2C商城 小程序商城 H5商城 APP商城 ，本商城是前后端分离的商城、微服务架构商城。|344|2022-02-09|2021-09-13|
|40|[UxxHans/Rainbow-Cats-Personal-WeChat-MiniProgram](https://github.com/UxxHans/Rainbow-Cats-Personal-WeChat-MiniProgram)|给女朋友做的微信小程序！情侣自己的任务和商城系统！|339|2022-07-21|2022-04-05|
|41|[aoaostar/toolbox](https://github.com/aoaostar/toolbox)|🚀傲星工具箱，一个在线工具箱|324|2022-03-18|2021-12-21|
|42|[CloudWise-OpenSource/FlyFish](https://github.com/CloudWise-OpenSource/FlyFish)|FlyFish is a data visualization coding platform. We can create a data model quickly in a simple way, and quickly generate a set of data visualization solutions by dragging.|312|2022-07-29|2021-10-08|
|43|[sansui-orz/bilibili2local](https://github.com/sansui-orz/bilibili2local)|bilibili视频下载命令行工具|305|2022-05-07|2022-04-20|
|44|[Sean529/robFood](https://github.com/Sean529/robFood)|因为上海疫情，用于抢菜~|303|2022-06-21|2022-04-01|
|45|[fishingworld/something](https://github.com/fishingworld/something)|个人用Surge Panel脚本|301|2022-07-26|2021-10-01|
|46|[qulingyuan/robVeg](https://github.com/qulingyuan/robVeg)|美团买菜 抢菜脚本|293|2022-04-08|2022-04-06|
|47|[Abbbbbi/Frida-Seccomp](https://github.com/Abbbbbi/Frida-Seccomp)|一个Android通用svc跟踪以及hook方案——Frida-Seccomp|287|2022-03-11|2022-03-11|
|48|[open-mmlab/labelbee-client](https://github.com/open-mmlab/labelbee-client)|Out-of-the-box Annotation Toolbox|287|2022-06-20|2021-12-03|
|49|[skygongque/tts](https://github.com/skygongque/tts)|微软azure文本转语音 音频下载|282|2022-06-06|2022-03-13|
|50|[Mustard404/Savior](https://github.com/Mustard404/Savior)|渗透测试报告自动生成工具！|274|2022-05-09|2021-11-10|
|51|[sun0225SUN/Awesome-Love-Code](https://github.com/sun0225SUN/Awesome-Love-Code)|表白代码收藏馆~谁说程序猿不懂浪漫❤️|269|2022-02-16|2022-01-27|
|52|[itorr/bionic-reading.user.js](https://github.com/itorr/bionic-reading.user.js)|网页英文前部加粗 用户脚本|258|2022-05-25|2022-05-19|
|53|[sudongyuer/learn-eslint](https://github.com/sudongyuer/learn-eslint)|🦥 从0到1全面掌握ESLint|255|2022-07-22|2022-06-23|
|54|[jxhczhl/JsRpc](https://github.com/jxhczhl/JsRpc)|jsrpc,在浏览器开启一个ws和服务连接，以请求http接口的形式来和浏览器通信 ,浏览器端收到调用通信执行原先设置好的js代码并获得返回值。|228|2022-07-14|2021-09-25|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
