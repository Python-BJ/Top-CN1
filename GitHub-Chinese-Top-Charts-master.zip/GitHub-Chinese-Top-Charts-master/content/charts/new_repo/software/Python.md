<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文新秀榜 > 软件类 > Python
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Updated|Created|
|:-|:-|:-|:-|:-|:-|
|1|[OpenEthan/SMSBoom](https://github.com/OpenEthan/SMSBoom)|短信轰炸/短信测压/   一个健壮免费的python短信轰炸程序，专门炸坏蛋蛋，百万接口，多线程全自动添加有效接口，支持异步协程百万并发，全免费的短信轰炸工具！！hongkonger开发全网首发！！|6044|2022-07-21|2021-08-10|
|2|[hpcaitech/ColossalAI](https://github.com/hpcaitech/ColossalAI)|Colossal-AI: A Unified Deep Learning System for Big Model Era|4547|2022-08-02|2021-10-28|
|3|[7eu7d7/genshin_auto_fish](https://github.com/7eu7d7/genshin_auto_fish)|基于深度强化学习的原神自动钓鱼AI|3984|2022-02-28|2021-09-10|
|4|[jxxghp/nas-tools](https://github.com/jxxghp/nas-tools)|NAS媒体库资源归集、整理自动化工具|1753|2022-08-02|2021-08-04|
|5|[louisyoungx/jd-shopper](https://github.com/louisyoungx/jd-shopper)|京东自动下单 (自动登录,指定时间预约商品,商品补货监控,自动加购物车,自动下单)|1672|2022-03-20|2021-11-22|
|6|[martinet101/ElevenClock](https://github.com/martinet101/ElevenClock)|ElevenClock: Have a customizable clock on your Windows 11 displays|1422|2022-08-02|2021-09-19|
|7|[pofey/movie_robot](https://github.com/pofey/movie_robot)|轻松便捷的与家人和朋友，一同享受多终端- 致的高品质私有化观影体验。|1396|2022-07-23|2022-01-27|
|8|[Mas0nShi/typoraCracker](https://github.com/Mas0nShi/typoraCracker)|A extract & decryption and pack & encryption tools for typora.|1394|2022-04-06|2021-11-30|
|9|[fslongjin/This-repo-has-1248-stars](https://github.com/fslongjin/This-repo-has-1248-stars)|这个仓库有1248个star，不信你试试|1248|2022-07-29|2022-06-14|
|10|[chen310/NeteaseCloudMusicTasks](https://github.com/chen310/NeteaseCloudMusicTasks)|-|1226|2022-04-18|2021-12-09|
|11|[Johnshall/Shadowrocket-ADBlock-Rules-Forever](https://github.com/Johnshall/Shadowrocket-ADBlock-Rules-Forever)|提供多款 Shadowrocket 规则，拥有强劲的广告过滤功能。每日8时重新构建规则。|1213|2022-08-01|2021-12-06|
|12|[hustvl/YOLOP](https://github.com/hustvl/YOLOP)|You Only Look Once for Panopitic Driving Perception.（https://arxiv.org/abs/2108.11250）|1193|2022-07-21|2021-08-25|
|13|[Tencent/CodeAnalysis](https://github.com/Tencent/CodeAnalysis)|Static Code Analysis - 静态代码分析|1192|2022-08-02|2021-12-28|
|14|[EstrellaXD/Auto_Bangumi](https://github.com/EstrellaXD/Auto_Bangumi)|AutoBangumi - 全自动追番工具，节约时间创造价值|1180|2022-08-02|2022-05-03|
|15|[78778443/QingScan](https://github.com/78778443/QingScan)|一个漏洞扫描器粘合剂,添加目标后30款工具自动调用；支持 web扫描、系统扫描、子域名收集、目录扫描、主机扫描、主机发现、组件识别、URL爬虫、XRAY扫描、AWVS自动扫描、POC批量验证，SSH批量测试、vulmap。|1081|2022-08-02|2021-12-06|
|16|[open-mmlab/mmdeploy](https://github.com/open-mmlab/mmdeploy)|OpenMMLab Model Deployment Framework|1070|2022-07-20|2021-12-24|
|17|[Jack-Cherish/quantitative](https://github.com/Jack-Cherish/quantitative)|量化交易：python3|1020|2022-05-05|2021-09-08|
|18|[Zy143L/wskey](https://github.com/Zy143L/wskey)|wskey|1001|2022-05-25|2021-09-01|
|19|[tr0uble-mAker/POC-bomber](https://github.com/tr0uble-mAker/POC-bomber)|利用大量高威胁poc/exp快速获取目标权限，用于渗透和红队快速打点|969|2022-07-30|2021-11-26|
|20|[BR-IDL/PaddleViT](https://github.com/BR-IDL/PaddleViT)|:robot: PaddleViT: State-of-the-art Visual Transformer and MLP Models for PaddlePaddle 2.0+|927|2022-07-15|2021-08-30|
|21|[google/budoux](https://github.com/google/budoux)|-|838|2022-07-29|2021-11-18|
|22|[enpeizhao/CVprojects](https://github.com/enpeizhao/CVprojects)|computer vision projects    计算机视觉等好玩的AI项目|770|2022-07-28|2021-11-22|
|23|[open-mmlab/mmrazor](https://github.com/open-mmlab/mmrazor)|OpenMMLab Model Compression Toolbox and Benchmark.|683|2022-08-02|2021-12-22|
|24|[why20021008/hand-write](https://github.com/why20021008/hand-write)|模拟手写效果，节约时间。|631|2022-04-30|2022-04-04|
|25|[ctripcorp/flybirds](https://github.com/ctripcorp/flybirds)|基于自然语言的，跨端跨框架 BDD UI 自动化测试方案，BDD testing, Python style, Present by Trip Flight|623|2022-08-02|2021-12-30|
|26|[open-mmlab/mmhuman3d](https://github.com/open-mmlab/mmhuman3d)|OpenMMLab 3D Human Parametric Model Toolbox and Benchmark|594|2022-07-29|2021-11-29|
|27|[open-mmlab/mmflow](https://github.com/open-mmlab/mmflow)|OpenMMLab optical flow toolbox and benchmark|584|2022-07-31|2021-11-16|
|28|[W01fh4cker/Serein](https://github.com/W01fh4cker/Serein)|【懒人神器】一款图形化、批量采集url、批量对采集的url进行各种nday检测的工具。可用于src挖掘、cnvd挖掘、0day利用、打造自己的武器库等场景。可以批量利用Actively Exploited Atlassian Confluence 0Day CVE-2022-26134和DedeCMS v5.7.87 SQL注入 CVE-2022-23337。|572|2022-08-02|2022-05-31|
|29|[Gumpest/YOLOv5-Multibackbone-Compression](https://github.com/Gumpest/YOLOv5-Multibackbone-Compression)|YOLOv5 Series Multi-backbone(TPH-YOLOv5, Ghostnet, ShuffleNetv2, Mobilenetv3Small, EfficientNetLite, PP-LCNet, SwinTransformer YOLO), Module(CBAM, DCN), Pruning (EagleEye, Network Slimming), Quantizat ...|572|2022-04-29|2021-10-26|
|30|[UzJu/Cloud-Bucket-Leak-Detection-Tools](https://github.com/UzJu/Cloud-Bucket-Leak-Detection-Tools)|六大云存储，泄露利用检测工具|565|2022-07-16|2022-02-22|
|31|[yuezih/King-of-Pigeon](https://github.com/yuezih/King-of-Pigeon)|欢迎 star ，有机会会继续更新。|530|2022-04-08|2021-09-13|
|32|[bubbliiiing/yolox-pytorch](https://github.com/bubbliiiing/yolox-pytorch)|这是一个yolox-pytorch的源码，可以用于训练自己的模型。|497|2022-07-16|2021-09-04|
|33|[CMHopeSunshine/LittlePaimon](https://github.com/CMHopeSunshine/LittlePaimon)|小派蒙！原神qq群机器人，基于NoneBot2的UID查询、抽卡导出分析、模拟抽卡、实时便签、札记等多功能小助手。|487|2022-07-30|2022-03-13|
|34|[Evil0ctal/Douyin_TikTok_Download_API](https://github.com/Evil0ctal/Douyin_TikTok_Download_API)|不依赖任何第三方网站实现在线批量TikTok/抖音解析下载无水印视频/图集，并将结果显示在网页上。同时支持API调用，可配合iOS快捷指令APP实现应用内下载。免费，开源，无广告，长期维护。|482|2022-07-19|2021-11-07|
|35|[XiaoMiku01/fansMedalHelper](https://github.com/XiaoMiku01/fansMedalHelper)|新版B站粉丝牌助手 全自动升级粉丝牌|480|2022-08-02|2022-05-24|
|36|[hiroi-sora/Umi-OCR](https://github.com/hiroi-sora/Umi-OCR)|OCR离线批量图片文字识别软件，带界面。可排除视频图片中的水印、游戏图片中的UI等干扰，提取干净的文本。基于 PaddleOCR 。|475|2022-07-22|2022-03-28|
|37|[lucky-ecat/wechat_info_collect](https://github.com/lucky-ecat/wechat_info_collect)|调查取证   针对微信客户端的信息收集工具, 自动化提取本地PC所有的微信信息, 包括微信号, 手机号等  |459|2022-07-26|2022-05-05|
|38|[murufeng/awesome_lightweight_networks](https://github.com/murufeng/awesome_lightweight_networks)|The implementation of various lightweight networks by using PyTorch. such as：MobileNetV2，MobileNeXt，GhostNet，ParNet，MobileViT、AdderNet，ShuffleNetV1-V2，LCNet，ConvNeXt，etc. ⭐⭐⭐⭐⭐|448|2022-05-16|2021-08-13|
|39|[tencentmusic/cube-studio](https://github.com/tencentmusic/cube-studio)|云原生一站式机器学习平台，多租户，notebook在线开发，拖拉拽任务流编排，多机多卡分布式训练，超参搜索，推理服务，多集群调度，多项目组资源组，边缘计算，大模型实时训练|431|2022-07-31|2021-08-17|
|40|[nschloe/matplotx](https://github.com/nschloe/matplotx)|:bar_chart: More styles and useful extensions for Matplotlib|425|2022-06-15|2021-10-24|
|41|[QIN2DIM/epic-awesome-gamer](https://github.com/QIN2DIM/epic-awesome-gamer)|🍷 Gracefully claim weekly free games and monthly content from Epic Store.|402|2022-07-27|2022-01-15|
|42|[0x727/FingerprintHub](https://github.com/0x727/FingerprintHub)|侦查守卫(ObserverWard)的指纹库|392|2022-05-22|2021-08-20|
|43|[MoonInTheRiver/DiffSinger](https://github.com/MoonInTheRiver/DiffSinger)|DiffSinger: Singing Voice Synthesis via Shallow Diffusion Mechanism (SVS & TTS); AAAI 2022; Official code|391|2022-08-02|2021-12-17|
|44|[IDEA-CCNL/Fengshenbang-LM](https://github.com/IDEA-CCNL/Fengshenbang-LM)|Fengshenbang-LM(封神榜大模型)是IDEA研究院认知计算与自然语言研究中心主导的大模型开源体系|382|2022-08-01|2021-10-28|
|45|[lwm98/health160](https://github.com/lwm98/health160)|健康160自动挂号脚本，用魔法对抗魔法，禁止商用🖖|376|2022-06-29|2021-10-14|
|46|[bubbliiiing/yolov5-pytorch](https://github.com/bubbliiiing/yolov5-pytorch)|这是一个YoloV5-pytorch的源码，可以用于训练自己的模型。|368|2022-07-16|2022-01-15|
|47|[daydreaming666/Amenoma](https://github.com/daydreaming666/Amenoma)|A simple desktop application to scan and export Genshin Impact Artifacts and Materials.|358|2022-07-27|2021-08-24|
|48|[HFrost0/bilix](https://github.com/HFrost0/bilix)|⚡️快如闪电的bilibili下载工具，基于Python现代Async特性，高速批量下载整部动漫，电视剧，up投稿等|354|2022-07-25|2022-04-03|
|49|[JiehangXie/PaddleBoBo](https://github.com/JiehangXie/PaddleBoBo)|基于飞桨开发的虚拟主播|343|2022-05-04|2021-12-22|
|50|[alibaba/TinyNeuralNetwork](https://github.com/alibaba/TinyNeuralNetwork)|TinyNeuralNetwork is an efficient and easy-to-use deep learning model compression framework.|343|2022-08-01|2021-11-02|
|51|[Taonn/EmailAll](https://github.com/Taonn/EmailAll)|EmailAll is a powerful Email Collect tool — 一款强大的邮箱收集工具|333|2022-03-04|2022-02-14|
|52|[HuKai97/yolov5-5.x-annotations](https://github.com/HuKai97/yolov5-5.x-annotations)|一个基于yolov5-5.0的中文注释版本！|333|2022-06-17|2021-08-28|
|53|[komomon/CVE-2022-30190-follina-Office-MSDT-Fixed](https://github.com/komomon/CVE-2022-30190-follina-Office-MSDT-Fixed)|CVE-2022-30190-follina.py-修改版，可以自定义word模板，方便实战中钓鱼使用。|323|2022-06-06|2022-06-02|
|54|[VulnTotal-Team/Vehicle-Security-Toolkit](https://github.com/VulnTotal-Team/Vehicle-Security-Toolkit)|汽车/安卓/固件/代码安全测试工具集|321|2022-07-29|2021-08-03|
|55|[kuangdd/ttskit](https://github.com/kuangdd/ttskit)|text to speech toolkit. 好用的中文语音合成工具箱，包含语音编码器、语音合成器、声码器和可视化模块。|320|2022-02-20|2021-10-03|
|56|[Javacr/PyQt5-YOLOv5](https://github.com/Javacr/PyQt5-YOLOv5)|YOLOv5检测界面-PyQt5实现|317|2022-05-31|2021-09-28|
|57|[lxflxfcl/monitor](https://github.com/lxflxfcl/monitor)|漏洞监控平台——Monitor。目前实现了监控GitHub、微软、CNNVD三者的漏洞信息，并使用企业微信实时推送。还可以使用邮箱推送，默认关闭。|295|2022-02-10|2022-01-22|
|58|[XiaoMiku01/bili-live-heart](https://github.com/XiaoMiku01/bili-live-heart)|[已失效 新版 XiaoMiku01/fansMedalHelper]每日获取B站直播间每日小心心及直播间自动打卡脚本|294|2022-05-31|2021-10-28|
|59|[OpenBMB/BMInf](https://github.com/OpenBMB/BMInf)|Efficient Inference for Big Models|288|2022-07-31|2021-08-24|
|60|[RimoChan/sese-engine](https://github.com/RimoChan/sese-engine)|【sese-engine】新时代的搜索引擎！|287|2022-07-15|2022-01-09|
|61|[ExpLangcn/WanLi](https://github.com/ExpLangcn/WanLi)|方便红队人员对目标站点进行安全检测，快速获取资产。It is convenient for red team personnel to conduct security detection on the target site and quickly obtain assets.|286|2022-05-12|2022-01-12|
|62|[Jianghuchengphilip/Generate-NFT](https://github.com/Jianghuchengphilip/Generate-NFT)|Generate-NFT是由B站UP主Philipjhc倾力打造的批量生成NFT的工具|267|2022-04-27|2022-01-12|
|63|[vinjn/perf-doctor](https://github.com/vinjn/perf-doctor)|性能医生, a mobile game profiler.|264|2022-08-01|2021-09-24|
|64|[iframepm/FuckAV](https://github.com/iframepm/FuckAV)|python写的一款免杀工具（shellcode加载器）BypassAV，国内杀软全过（windows denfend）2021-9-13|263|2022-06-22|2021-08-20|
|65|[CarltonHere/auto-cpdaily](https://github.com/CarltonHere/auto-cpdaily)|今日校园自动化是一个基于Python的爬虫项目，主要实现今日校园签到、信息收集、查寝等循环表单的自动化任务|259|2022-06-15|2021-08-16|
|66|[jtl1207/comic-translation](https://github.com/jtl1207/comic-translation)|基于深度学习的漫画翻译辅助工具，包含翻译、朗读、图像去字、自动嵌字功能。  目的是帮助非专业汉化人员完成更简单，快速的翻译任务。|258|2022-03-26|2022-03-02|
|67|[JimmyLiang-lzm/biliDownloader_GUI](https://github.com/JimmyLiang-lzm/biliDownloader_GUI)|B站视频下载程序，BiliBili视频下载器，支持下载B站视频、交互\互动视频，支持下载区域限制视频资源。Bili Downloader GUI Program for Stable.😊|258|2022-07-23|2021-10-06|
|68|[zhaoyun0071/Disco-Diffusion-Local](https://github.com/zhaoyun0071/Disco-Diffusion-Local)|只要是Windows系统，5-6G以上显存的英伟达显卡，下载解压就能直接用，什么环境都不用配置|253|2022-07-30|2022-04-23|
|69|[sipeed/Maix-Speech](https://github.com/sipeed/Maix-Speech)|Maix Speech AI lib, a fast and small speech lib running on embedded devices, including ASR, chat, TTS etc.|237|2022-03-07|2021-10-15|
|70|[gh0stkey/Command2API](https://github.com/gh0stkey/Command2API)|Command2API - 万物皆可API|223|2022-02-08|2021-12-12|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
