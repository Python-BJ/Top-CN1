<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文增速榜 > 资料类 > R
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Average daily growth|Updated|
|:-|:-|:-|:-|:-|:-|
|1|[briatte/awesome-network-analysis](https://github.com/briatte/awesome-network-analysis)|A curated list of awesome network analysis resources.|2744|1|2022-05-01|
|2|[Lchiffon/Rweixin](https://github.com/Lchiffon/Rweixin)|R语言与微信公众号接口|21|0|2022-06-13|
|3|[cosname/rmarkdown-guide](https://github.com/cosname/rmarkdown-guide)|R Markdown 指南（一本八字还没一撇的中文书）|43|0|2022-07-17|
|4|[yufree/sciguide](https://github.com/yufree/sciguide)|现代科研指北|79|0|2022-07-09|
|5|[rpkgs/gg.layers](https://github.com/rpkgs/gg.layers)|ggplot2 extensions 入门|11|0|2022-05-19|
|6|[Sfeng666/2022_tax_filing](https://github.com/Sfeng666/2022_tax_filing)|2022税季 UW-Madison报税指南|4|0|2022-03-22|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
