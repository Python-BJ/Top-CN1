<a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a>

# 中文增速榜 > 资料类 > Assembly
<sub>数据更新: 2022-08-03&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;温馨提示：中文项目泛指「文档母语为中文」OR「含有中文翻译」的项目，通常在项目的「readme/wiki/官网」可以找到</sub>

|#|Repository|Description|Stars|Average daily growth|Updated|
|:-|:-|:-|:-|:-|:-|
|1|[Jolsonz/hust_kaoyan](https://github.com/Jolsonz/hust_kaoyan)|本人参与2020华中科技大学研究生考试复试期间所作的一些笔记，主要是数据库和汇编语言的。|8|0|2022-03-01|
|2|[Starrylay/awesome-HUST-CS-MIPS-CPU](https://github.com/Starrylay/awesome-HUST-CS-MIPS-CPU)|HUSTCS19级沈承磊的组原课设/华中科技大学计算机组成原理课程设计/MIPS五段流水CPU/华中科技大学计算机组成原理课程设计/华科组原课设/MIPS-CPU/单周期/流水线/分支预测。来自学长的溺爱x，让你copy的明白。|3|0|2022-03-26|
|3|[Trap1124/Digital-Logic-and-Computer-Organization](https://github.com/Trap1124/Digital-Logic-and-Computer-Organization)|南京大学计算机系2021秋季学期数字逻辑与计算机组成课程实验|4|0|2022-02-17|
|4|[web1992/read](https://github.com/web1992/read)|学习笔记 dubbo,rocketmq 源码解析|30|0|2022-04-03|
|5|[lib-hfut/lib-hfut](https://github.com/lib-hfut/lib-hfut)|贵校课程资料民间整理|182|0|2022-03-11|
|6|[Staok/ARM-Linux-Study](https://github.com/Staok/ARM-Linux-Study)|ARM Linux 的学习历程，文章遵守 CC BY NC SA 4.0 协议。|8|0|2022-03-24|

<div align="center">
    <p><sub>↓ -- 感谢读者 -- ↓</sub></p>
    榜单持续更新，如有帮助请加星收藏，方便后续浏览，感谢你的支持！
</div>

<br/>

<div align="center"><a href="https://github.com/GrowingGit/GitHub-Chinese-Top-Charts#github中文排行榜">返回目录</a> • <a href="/content/docs/feedback.md">问题反馈</a></div>
