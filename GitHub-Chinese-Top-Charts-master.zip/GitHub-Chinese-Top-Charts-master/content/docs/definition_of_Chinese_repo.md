[< 返回](https://github.com/kon9chunkit/GitHub-Chinese-Top-Charts#github中文排行榜)

# 中文项目定义

泛指一切包含中文文档/说明的项目：
- readme主语言是中文；
- readme主语言是英文，但有中文版本；
- readme主语言是英文，但wiki有中文文档；
- readme主语言是英文，但项目官网有中文文档；
