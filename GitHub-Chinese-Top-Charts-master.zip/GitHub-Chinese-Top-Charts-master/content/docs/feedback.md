[< 返回](https://github.com/kon9chunkit/GitHub-Chinese-Top-Charts#github中文排行榜)

# 问题反馈

- 本项目通过程序+人工综合实现，维护工作量较大，目前可能存在不准确的分类，请大家理解；
- 如果大家发现有错误的情况，请提交issue给我，我会尽早更新处理；
- 提交问题请注明 榜单类型、软件/资料、排名位置；
