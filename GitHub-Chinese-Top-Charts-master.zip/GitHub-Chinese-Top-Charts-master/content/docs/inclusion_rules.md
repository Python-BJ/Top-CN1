[< 返回](https://github.com/kon9chunkit/GitHub-Chinese-Top-Charts#github中文排行榜)

# 收录规则

- 不涉政、宗、黄、暴；
- 不涉翻墙工具；
- 持续活跃更新；

注意：收录只是进入评估池，不代表上榜；